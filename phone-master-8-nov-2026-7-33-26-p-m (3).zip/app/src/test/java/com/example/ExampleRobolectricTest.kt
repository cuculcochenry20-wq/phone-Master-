package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.formatBytes
import com.example.data.model.BatteryMode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Phone Master", appName)
  }

  @Test
  fun `verify byte formatting`() {
    assertEquals("0 MB", formatBytes(0))
    assertEquals("500 KB", formatBytes(500 * 1024))
    assertEquals("25.0 MB", formatBytes(25 * 1024 * 1024))
    assertEquals("1.50 GB", formatBytes((1.5 * 1024 * 1024 * 1024).toLong()))
  }

  @Test
  fun `verify battery modes`() {
    assertTrue(BatteryMode.ULTRA_SAVER.extraHours > BatteryMode.NORMAL.extraHours)
    assertTrue(BatteryMode.TURBO.isTurbo)
  }

  @Test
  fun `verify hibernation model`() {
    val app = com.example.data.model.HibernationAppItem(
        packageName = "com.test.app",
        appName = "Test App",
        drainPercentPerHour = 6.5f,
        estimatedMahDrain = 160,
        drainLevel = com.example.data.model.DrainLevel.HIGH
    )
    assertEquals(com.example.data.model.DrainLevel.HIGH, app.drainLevel)
    assertTrue(app.drainPercentPerHour > 5.0f)
  }

  @Test
  fun `verify audio equalizer band formatting`() {
    val bandLow = com.example.data.model.EqualizerBand(0, 60, -1500, 1500, 500)
    val bandHigh = com.example.data.model.EqualizerBand(4, 14000, -1500, 1500, -300)
    assertEquals("60 Hz", bandLow.freqFormatted)
    assertEquals("+5 dB", bandLow.levelFormatted)
    assertEquals("14 kHz", bandHigh.freqFormatted)
    assertEquals("-3 dB", bandHigh.levelFormatted)
  }
}
