package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.DeviceThermostat
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CpuThermalInfo
import com.example.ui.components.PhoneMasterTopBar
import com.example.ui.theme.TecnoAmberWarning
import com.example.ui.theme.TecnoCyanGlow
import com.example.ui.theme.TecnoGreenSuccess
import com.example.ui.theme.TecnoNavyCard
import com.example.ui.theme.TecnoNavyCardBorder
import com.example.ui.theme.TecnoNavyDark
import com.example.ui.theme.TecnoRedDanger
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark

@Composable
fun CpuCoolerScreen(
    cpuInfo: CpuThermalInfo,
    isCooling: Boolean,
    onCoolCpu: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val tempColor = when {
        cpuInfo.temperatureCelsius > 40f -> TecnoRedDanger
        cpuInfo.temperatureCelsius > 35f -> TecnoAmberWarning
        else -> TecnoCyanGlow
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(TecnoNavyDark)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            PhoneMasterTopBar(
                title = "Enfriador de CPU",
                subtitle = "Gestión Térmica HiOS",
                showBackButton = true,
                onBackClick = onBack
            )

            // Temperature Hero Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(TecnoNavyCard, TecnoNavyCard.copy(alpha = 0.8f))
                        )
                    )
                    .border(1.dp, TecnoNavyCardBorder, RoundedCornerShape(20.dp))
                    .padding(24.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .size(70.dp)
                            .clip(CircleShape)
                            .background(tempColor.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeviceThermostat,
                            contentDescription = "Temperatura CPU",
                            tint = tempColor,
                            modifier = Modifier.size(38.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "${String.format("%.1f", cpuInfo.temperatureCelsius)} °C",
                        fontSize = 42.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = tempColor
                    )

                    Text(
                        text = "Estado Térmico: ${cpuInfo.statusText}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextSecondaryDark
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (cpuInfo.isOverheated) TecnoRedDanger.copy(alpha = 0.15f)
                                else TecnoGreenSuccess.copy(alpha = 0.15f)
                            )
                            .padding(horizontal = 12.dp, vertical = 5.dp)
                    ) {
                        Text(
                            text = if (cpuInfo.isOverheated) "¡Atención! Carga alta detectada" else "Temperatura dentro de rango seguro",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (cpuInfo.isOverheated) TecnoRedDanger else TecnoGreenSuccess
                        )
                    }
                }
            }

            // Hardware Stats Cards
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                HardwareMetricRow(
                    icon = Icons.Default.Memory,
                    title = "Carga de Procesador (CPU)",
                    value = "${cpuInfo.cpuUsagePercent}%",
                    subtitle = "${Runtime.getRuntime().availableProcessors()} núcleos activos"
                )

                HardwareMetricRow(
                    icon = Icons.Default.GraphicEq,
                    title = "Rendimiento Gráfico (GPU)",
                    value = cpuInfo.gpuStatusText,
                    subtitle = "Perfil dinámico de energía"
                )

                HardwareMetricRow(
                    icon = Icons.Default.Warning,
                    title = "Aplicaciones que generan calor",
                    value = "${cpuInfo.hotAppsCount} apps",
                    subtitle = "Procesos en segundo plano optimizables"
                )
            }
        }

        // Bottom Cooling Button
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(TecnoNavyDark)
                .padding(16.dp)
        ) {
            Button(
                onClick = onCoolCpu,
                enabled = !isCooling,
                modifier = Modifier
                    .testTag("cool_cpu_button")
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF00B0FF),
                    disabledContainerColor = TecnoNavyCardBorder
                )
            ) {
                if (isCooling) {
                    CircularProgressIndicator(
                        color = Color.White,
                        modifier = Modifier.size(24.dp),
                        strokeWidth = 2.5.dp
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Enfriando CPU y GPU...",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.AcUnit,
                            contentDescription = "Enfriar",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "ENFRIAR AHORA",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HardwareMetricRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    value: String,
    subtitle: String
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(TecnoNavyCard)
            .border(1.dp, TecnoNavyCardBorder, RoundedCornerShape(14.dp))
            .padding(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF00B0FF).copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = Color(0xFF00B0FF),
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimaryDark
                    )
                    Text(
                        text = subtitle,
                        fontSize = 11.sp,
                        color = TextSecondaryDark
                    )
                }
            }

            Text(
                text = value,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TecnoCyanGlow
            )
        }
    }
}
