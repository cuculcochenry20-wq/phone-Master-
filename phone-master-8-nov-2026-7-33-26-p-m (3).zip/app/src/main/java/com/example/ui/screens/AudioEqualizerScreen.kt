package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speaker
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.SurroundSound
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.audio.AudioEnhancerManager
import com.example.data.model.AudioEnhancerState
import com.example.data.model.EqualizerPreset
import com.example.ui.components.PhoneMasterTopBar
import com.example.ui.theme.TecnoAmberWarning
import com.example.ui.theme.TecnoBluePrimary
import com.example.ui.theme.TecnoCyanGlow
import com.example.ui.theme.TecnoGreenSuccess
import com.example.ui.theme.TecnoNavyCard
import com.example.ui.theme.TecnoNavyCardBorder
import com.example.ui.theme.TecnoNavyDark
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark

@Composable
fun AudioEqualizerScreen(
    audioState: AudioEnhancerState,
    factoryPresets: List<EqualizerPreset>,
    onToggleEnabled: (Boolean) -> Unit,
    onSelectPreset: (EqualizerPreset) -> Unit,
    onBandChange: (Int, Int) -> Unit,
    onBassBoostChange: (Int) -> Unit,
    onLoudnessChange: (Int) -> Unit,
    onVirtualizerChange: (Int) -> Unit,
    onSaveCustomPreset: (String) -> Unit,
    onDeleteCustomPreset: (String) -> Unit,
    onToggleTestTone: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    var showSaveDialog by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(TecnoNavyDark)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            PhoneMasterTopBar(
                title = "Ecualizador y Sonido",
                subtitle = "Mejora de Audio y Altavoz HiOS",
                showBackButton = true,
                onBackClick = onBack
            )

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 4.dp, bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Master Enable / Mode Card
                item {
                    Box(
                        modifier = Modifier
                            .testTag("audio_master_switch_card")
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(
                                Brush.linearGradient(
                                    if (audioState.isEnabled) listOf(Color(0xFF0F2D54), TecnoNavyCard)
                                    else listOf(TecnoNavyCard, TecnoNavyCard)
                                )
                            )
                            .border(
                                1.5.dp,
                                if (audioState.isEnabled) TecnoCyanGlow else TecnoNavyCardBorder,
                                RoundedCornerShape(20.dp)
                            )
                            .padding(18.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(CircleShape)
                                        .background(
                                            if (audioState.isEnabled) Brush.linearGradient(listOf(Color(0xFF0075FF), Color(0xFF00E5FF)))
                                            else Brush.linearGradient(listOf(TecnoNavyCardBorder, TecnoNavyCardBorder))
                                        ),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.GraphicEq,
                                        contentDescription = "Ecualizador",
                                        tint = if (audioState.isEnabled) Color.Black else TextSecondaryDark,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column {
                                    Text(
                                        text = "Mejora de Sonido Activa",
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (audioState.isEnabled) TecnoCyanGlow else TextPrimaryDark
                                    )
                                    Text(
                                        text = if (audioState.isEnabled) "Optimizando salida al altavoz y auriculares" else "Efectos de audio desactivados",
                                        fontSize = 11.sp,
                                        color = TextSecondaryDark
                                    )
                                }
                            }

                            Switch(
                                checked = audioState.isEnabled,
                                onCheckedChange = onToggleEnabled,
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.Black,
                                    checkedTrackColor = TecnoCyanGlow,
                                    uncheckedThumbColor = TextSecondaryDark,
                                    uncheckedTrackColor = TecnoNavyCardBorder
                                )
                            )
                        }
                    }
                }

                // Presets Bar (Factory & Custom)
                item {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Ajustes Preestablecidos",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark
                            )

                            Text(
                                text = "+ Guardar Actual",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = TecnoCyanGlow,
                                modifier = Modifier
                                    .clickable { showSaveDialog = true }
                                    .padding(vertical = 4.dp, horizontal = 6.dp)
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        val allPresets = factoryPresets + audioState.customPresets
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            allPresets.forEach { preset ->
                                val isSelected = audioState.currentPresetId == preset.id
                                Box(
                                    modifier = Modifier
                                        .testTag("preset_chip_${preset.id}")
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(if (isSelected) TecnoCyanGlow else TecnoNavyCard)
                                        .border(
                                            1.dp,
                                            if (isSelected) TecnoCyanGlow else TecnoNavyCardBorder,
                                            RoundedCornerShape(12.dp)
                                        )
                                        .clickable { onSelectPreset(preset) }
                                        .padding(horizontal = 14.dp, vertical = 8.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = preset.name,
                                            fontSize = 12.sp,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            color = if (isSelected) Color.Black else TextPrimaryDark
                                        )

                                        if (preset.isCustom) {
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Icon(
                                                imageVector = Icons.Default.Close,
                                                contentDescription = "Borrar preset",
                                                tint = if (isSelected) Color.Black else TextSecondaryDark,
                                                modifier = Modifier
                                                    .size(14.dp)
                                                    .clickable { onDeleteCustomPreset(preset.id) }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Dual Combination Sound Enhancer: Bajos con Volumen Más Alto
                item {
                    Text(
                        text = "Combinación de Bajos y Volumen",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryDark
                    )
                }

                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .background(TecnoNavyCard)
                            .border(1.dp, TecnoNavyCardBorder, RoundedCornerShape(18.dp))
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        // Bass Boost Slider
                        AudioEnhanceSlider(
                            icon = Icons.Default.Speaker,
                            title = "Refuerzo de Bajos (Bass Boost)",
                            valueText = "${(audioState.bassBoostStrength / 10)}%",
                            valueFraction = audioState.bassBoostStrength / 1000f,
                            accentColor = Color(0xFF00E5FF),
                            onValueChange = { onBassBoostChange((it * 1000).toInt()) }
                        )

                        // Loudness Volume Enhancer Slider
                        AudioEnhanceSlider(
                            icon = Icons.Default.VolumeUp,
                            title = "Potenciador de Volumen (Loudness)",
                            valueText = "+${audioState.loudnessGainMdB / 100} dB",
                            valueFraction = audioState.loudnessGainMdB / 1200f,
                            accentColor = Color(0xFFFF9100),
                            onValueChange = { onLoudnessChange((it * 1200).toInt()) }
                        )

                        // 3D Surround Virtualizer Slider
                        AudioEnhanceSlider(
                            icon = Icons.Default.SurroundSound,
                            title = "Efecto Envolvente 3D (Virtualizer)",
                            valueText = "${(audioState.virtualizerStrength / 10)}%",
                            valueFraction = audioState.virtualizerStrength / 1000f,
                            accentColor = Color(0xFF7C4DFF),
                            onValueChange = { onVirtualizerChange((it * 1000).toInt()) }
                        )
                    }
                }

                // 5-Band Graphic Equalizer
                item {
                    Text(
                        text = "Bandas de Ecualización Gráfica (Hz / kHz)",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryDark
                    )
                }

                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .background(TecnoNavyCard)
                            .border(1.dp, TecnoNavyCardBorder, RoundedCornerShape(18.dp))
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        audioState.bands.forEach { band ->
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = band.freqFormatted,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimaryDark,
                                    modifier = Modifier.width(62.dp)
                                )

                                val range = (band.maxLevelMdB - band.minLevelMdB).toFloat()
                                val fraction = if (range > 0) (band.currentLevelMdB - band.minLevelMdB) / range else 0.5f

                                Slider(
                                    value = fraction.coerceIn(0f, 1f),
                                    onValueChange = { f ->
                                        val newLevel = (band.minLevelMdB + (f * range)).toInt()
                                        onBandChange(band.index, newLevel)
                                    },
                                    modifier = Modifier.weight(1f),
                                    colors = SliderDefaults.colors(
                                        thumbColor = TecnoCyanGlow,
                                        activeTrackColor = TecnoCyanGlow,
                                        inactiveTrackColor = TecnoNavyCardBorder
                                    )
                                )

                                Text(
                                    text = band.levelFormatted,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TecnoCyanGlow,
                                    textAlign = TextAlign.End,
                                    modifier = Modifier.width(52.dp)
                                )
                            }
                        }
                    }
                }

                // Audio Test Tone Button
                item {
                    Button(
                        onClick = onToggleTestTone,
                        modifier = Modifier
                            .testTag("test_audio_tone_button")
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (audioState.isTestingTone) TecnoAmberWarning else TecnoNavyCardBorder
                        )
                    ) {
                        Icon(
                            imageVector = if (audioState.isTestingTone) Icons.Default.Stop else Icons.Default.PlayArrow,
                            contentDescription = "Probar sonido",
                            tint = if (audioState.isTestingTone) Color.Black else Color.White
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (audioState.isTestingTone) "DETENER PRUEBA DE SONIDO" else "PROBAR TONO DE BAJOS Y VOLUMEN",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (audioState.isTestingTone) Color.Black else Color.White
                        )
                    }
                }
            }
        }

        // Save Custom Preset Dialog
        if (showSaveDialog) {
            SavePresetDialog(
                onSave = { name ->
                    onSaveCustomPreset(name)
                    showSaveDialog = false
                },
                onDismiss = { showSaveDialog = false }
            )
        }
    }
}

@Composable
private fun AudioEnhanceSlider(
    icon: ImageVector,
    title: String,
    valueText: String,
    valueFraction: Float,
    accentColor: Color,
    onValueChange: (Float) -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = accentColor,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimaryDark
                )
            }

            Text(
                text = valueText,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = accentColor
            )
        }

        Slider(
            value = valueFraction.coerceIn(0f, 1f),
            onValueChange = onValueChange,
            colors = SliderDefaults.colors(
                thumbColor = accentColor,
                activeTrackColor = accentColor,
                inactiveTrackColor = TecnoNavyCardBorder
            ),
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun SavePresetDialog(
    onSave: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var presetName by remember { mutableStateOf("") }

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .testTag("save_preset_dialog")
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(TecnoNavyCard)
                .border(1.dp, TecnoCyanGlow.copy(alpha = 0.5f), RoundedCornerShape(22.dp))
                .padding(20.dp)
        ) {
            Column {
                Text(
                    text = "Guardar Ecualizador Personalizado",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryDark
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Guarda la combinación actual de bandas, bajos y volumen con un nombre propio.",
                    fontSize = 12.sp,
                    color = TextSecondaryDark
                )

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = presetName,
                    onValueChange = { presetName = it },
                    placeholder = { Text("Ej. Mi Mezcla Bajos + Potencia", fontSize = 13.sp, color = TextSecondaryDark) },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TecnoCyanGlow,
                        unfocusedBorderColor = TecnoNavyCardBorder,
                        focusedTextColor = TextPrimaryDark,
                        unfocusedTextColor = TextPrimaryDark
                    )
                )

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = TecnoNavyCardBorder)
                    ) {
                        Text("CANCELAR", fontSize = 12.sp, color = TextPrimaryDark)
                    }

                    Button(
                        onClick = { onSave(presetName) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = TecnoBluePrimary)
                    ) {
                        Text("GUARDAR", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    }
                }
            }
        }
    }
}
