package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import com.example.ui.components.RamBoostAnimation
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RamInfo
import com.example.data.model.RunningAppTask
import com.example.ui.components.PhoneMasterTopBar
import com.example.ui.theme.TecnoBluePrimary
import com.example.ui.theme.TecnoCyanGlow
import com.example.ui.theme.TecnoNavyCard
import com.example.ui.theme.TecnoNavyCardBorder
import com.example.ui.theme.TecnoNavyDark
import com.example.ui.theme.TecnoRedDanger
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark

@Composable
fun PhoneBoostScreen(
    ramInfo: RamInfo,
    tasks: List<RunningAppTask>,
    isBoosting: Boolean,
    onToggleTask: (String) -> Unit,
    onBoost: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val selectedTasks = tasks.filter { it.isSelected }
    val totalEstimatedFreeMb = selectedTasks.sumOf { it.ramUsageMb }

    val progressAnimated by animateFloatAsState(
        targetValue = (ramInfo.usedPercent / 100f).coerceIn(0f, 1f),
        animationSpec = tween(700),
        label = "ramProgress"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(TecnoNavyDark)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            PhoneMasterTopBar(
                title = "Acelerar Teléfono",
                subtitle = "Optimización de Memoria RAM",
                showBackButton = true,
                onBackClick = onBack
            )

            // RAM Usage Card
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(TecnoNavyCard)
                    .border(1.dp, TecnoNavyCardBorder, RoundedCornerShape(20.dp))
                    .padding(20.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(TecnoCyanGlow.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = "RAM",
                            tint = TecnoCyanGlow,
                            modifier = Modifier.size(30.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "${ramInfo.usedPercent}%",
                        fontSize = 38.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (ramInfo.usedPercent > 80) TecnoRedDanger else TecnoCyanGlow
                    )

                    Text(
                        text = "RAM en uso: ${ramInfo.usedGbFormatted} / ${ramInfo.totalGbFormatted}",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextSecondaryDark
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    LinearProgressIndicator(
                        progress = { progressAnimated },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp)),
                        color = if (ramInfo.usedPercent > 80) TecnoRedDanger else TecnoCyanGlow,
                        trackColor = TecnoNavyCardBorder.copy(alpha = 0.5f),
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Disponible: ${ramInfo.availableGbFormatted}",
                            fontSize = 11.sp,
                            color = TextSecondaryDark
                        )
                        Text(
                            text = if (ramInfo.isLowMemory) "Memoria baja detectada" else "Estado estable",
                            fontSize = 11.sp,
                            color = if (ramInfo.isLowMemory) TecnoRedDanger else TecnoCyanGlow
                        )
                    }
                }
            }

            // Section Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Aplicaciones en Segundo Plano (${tasks.size})",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryDark
                )

                Text(
                    text = "${selectedTasks.size} seleccionadas",
                    fontSize = 12.sp,
                    color = TecnoCyanGlow,
                    fontWeight = FontWeight.Medium
                )
            }

            // Tasks List
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(tasks, key = { it.packageName }) { task ->
                    Box(
                        modifier = Modifier
                            .testTag("task_item_${task.packageName}")
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(TecnoNavyCard)
                            .border(1.dp, TecnoNavyCardBorder, RoundedCornerShape(14.dp))
                            .clickable { onToggleTask(task.packageName) }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(TecnoBluePrimary.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Apps,
                                        contentDescription = task.appName,
                                        tint = TecnoCyanGlow,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column {
                                    Text(
                                        text = task.appName,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = TextPrimaryDark
                                    )
                                    Text(
                                        text = "${task.ramUsageMb} MB en uso",
                                        fontSize = 11.sp,
                                        color = TextSecondaryDark
                                    )
                                }
                            }

                            Checkbox(
                                checked = task.isSelected,
                                onCheckedChange = { onToggleTask(task.packageName) },
                                colors = CheckboxDefaults.colors(
                                    checkedColor = TecnoCyanGlow,
                                    checkmarkColor = Color.Black,
                                    uncheckedColor = TecnoNavyCardBorder
                                )
                            )
                        }
                    }
                }
            }
        }

        // Action Button
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(TecnoNavyDark)
                .padding(16.dp)
        ) {
            Button(
                onClick = onBoost,
                enabled = selectedTasks.isNotEmpty() && !isBoosting,
                modifier = Modifier
                    .testTag("boost_ram_button")
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = TecnoBluePrimary,
                    disabledContainerColor = TecnoNavyCardBorder
                )
            ) {
                if (isBoosting) {
                    CircularProgressIndicator(
                        color = Color.White,
                        modifier = Modifier.size(24.dp),
                        strokeWidth = 2.5.dp
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Liberando memoria RAM...",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.RocketLaunch,
                            contentDescription = "Acelerar",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (totalEstimatedFreeMb > 0) "ACELERAR Y LIBERAR (${totalEstimatedFreeMb} MB)" else "ACELERAR RAM",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }

        // High-Tech Compose Progress Animation Overlay
        AnimatedVisibility(
            visible = isBoosting,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            RamBoostAnimation(freedEstimatedMb = totalEstimatedFreeMb)
        }
    }
}
