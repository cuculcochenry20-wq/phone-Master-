package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.HourglassBottom
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BatteryInfo
import com.example.data.model.BatteryMode
import com.example.ui.components.PhoneMasterTopBar
import com.example.ui.theme.TecnoAmberWarning
import com.example.ui.theme.TecnoCyanGlow
import com.example.ui.theme.TecnoGreenSuccess
import com.example.ui.theme.TecnoNavyCard
import com.example.ui.theme.TecnoNavyCardBorder
import com.example.ui.theme.TecnoNavyDark
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark

@Composable
fun BatteryLabScreen(
    batteryInfo: BatteryInfo,
    onSelectMode: (BatteryMode) -> Unit,
    onNavigateToHibernation: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    var optimizeBrightness by remember { mutableStateOf(true) }
    var optimizeTimeout by remember { mutableStateOf(true) }
    var optimizeHaptics by remember { mutableStateOf(false) }
    var optimizeDarkMode by remember { mutableStateOf(true) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(TecnoNavyDark)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            PhoneMasterTopBar(
                title = "Laboratorio de Batería",
                subtitle = "Power Marathon HiOS",
                showBackButton = true,
                onBackClick = onBack
            )

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Battery Hero Card
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(
                                Brush.verticalGradient(
                                    listOf(TecnoNavyCard, TecnoNavyCard.copy(alpha = 0.7f))
                                )
                            )
                            .border(1.dp, TecnoNavyCardBorder, RoundedCornerShape(20.dp))
                            .padding(22.dp)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(TecnoAmberWarning.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = if (batteryInfo.isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryAlert,
                                    contentDescription = "Batería",
                                    tint = TecnoAmberWarning,
                                    modifier = Modifier.size(34.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = "${batteryInfo.levelPercent}%",
                                fontSize = 42.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = TextPrimaryDark
                            )

                            Text(
                                text = "Aproximadamente ${String.format("%.1f", batteryInfo.estimatedRemainingHours)} horas restantes",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = TecnoGreenSuccess
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Text(
                                text = if (batteryInfo.isCharging) "Conectado a ${batteryInfo.chargeSource}" else "Descargando en ${batteryInfo.activeMode.label}",
                                fontSize = 11.sp,
                                color = TextSecondaryDark
                            )
                        }
                    }
                }

                // Battery Telemetry Diagnostics Grid
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        DiagnosticChip(
                            label = "Salud Batería",
                            value = batteryInfo.health,
                            modifier = Modifier.weight(1f)
                        )
                        DiagnosticChip(
                            label = "Voltaje",
                            value = "${batteryInfo.voltageMv} mV",
                            modifier = Modifier.weight(1f)
                        )
                        DiagnosticChip(
                            label = "Temperatura",
                            value = "${String.format("%.1f", batteryInfo.temperatureCelsius)}°C",
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Freezer / App Hibernation Card
                item {
                    Box(
                        modifier = Modifier
                            .testTag("freezer_hibernation_card")
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(Color(0xFF0C2B47), TecnoNavyCard)
                                )
                            )
                            .border(1.dp, TecnoCyanGlow.copy(alpha = 0.35f), RoundedCornerShape(18.dp))
                            .clickable { onNavigateToHibernation() }
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                Box(
                                    modifier = Modifier
                                        .size(46.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(TecnoCyanGlow.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AcUnit,
                                        contentDescription = "Hibernación de Apps",
                                        tint = TecnoCyanGlow,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.width(14.dp))

                                Column {
                                    Text(
                                        text = "Congelador de Apps (Freezer)",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimaryDark
                                    )
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "Identifica apps de alto consumo y fuerza su detención",
                                        fontSize = 11.sp,
                                        color = TextSecondaryDark
                                    )
                                }
                            }

                            Icon(
                                imageVector = Icons.Default.ChevronRight,
                                contentDescription = "Abrir hibernación",
                                tint = TecnoCyanGlow
                            )
                        }
                    }
                }

                // Modo Turbo & Background Protection Hero Card
                item {
                    val isTurboActive = batteryInfo.activeMode == BatteryMode.TURBO
                    Box(
                        modifier = Modifier
                            .testTag("turbo_mode_banner_card")
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(20.dp))
                            .background(
                                Brush.linearGradient(
                                    if (isTurboActive) listOf(Color(0xFF2E0854), Color(0xFF003B73))
                                    else listOf(TecnoNavyCard, TecnoNavyCard)
                                )
                            )
                            .border(
                                1.5.dp,
                                if (isTurboActive) Color(0xFF00E5FF) else TecnoNavyCardBorder,
                                RoundedCornerShape(20.dp)
                            )
                            .padding(18.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                    Box(
                                        modifier = Modifier
                                            .size(46.dp)
                                            .clip(CircleShape)
                                            .background(
                                                if (isTurboActive) Brush.linearGradient(listOf(Color(0xFF7C4DFF), Color(0xFF00E5FF)))
                                                else Brush.linearGradient(listOf(TecnoNavyCardBorder, TecnoNavyCardBorder))
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.FlashOn,
                                            contentDescription = "Modo Turbo",
                                            tint = if (isTurboActive) Color.White else TextSecondaryDark,
                                            modifier = Modifier.size(26.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(12.dp))

                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = "Modo Turbo 100%",
                                                fontSize = 16.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = if (isTurboActive) Color(0xFF00E5FF) else TextPrimaryDark
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Box(
                                                modifier = Modifier
                                                    .clip(RoundedCornerShape(6.dp))
                                                    .background(if (isTurboActive) Color(0xFF7C4DFF) else TecnoNavyCardBorder)
                                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text(
                                                    text = if (isTurboActive) "ACTIVO" else "APAGADO",
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.ExtraBold,
                                                    color = Color.White
                                                )
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(2.dp))

                                        Text(
                                            text = "Optimización continua en 1er y 2do plano",
                                            fontSize = 11.sp,
                                            color = TextSecondaryDark
                                        )
                                    }
                                }

                                Switch(
                                    checked = isTurboActive,
                                    onCheckedChange = { checked ->
                                        if (checked) onSelectMode(BatteryMode.TURBO)
                                        else onSelectMode(BatteryMode.NORMAL)
                                    },
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = Color(0xFF00E5FF),
                                        uncheckedThumbColor = TextSecondaryDark,
                                        uncheckedTrackColor = TecnoNavyCardBorder
                                    )
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(TecnoNavyDark.copy(alpha = 0.6f))
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = if (isTurboActive) {
                                        "⚡ Servicio en segundo plano activo: La app continúa ejecutándose aunque cierres las apps recientes. Prioriza CPU, GPU y RAM en cualquier juego o aplicación pesada sin perder fluidez."
                                    } else {
                                        "Activa el Modo Turbo para mantener la aceleración continua sin perder rendimiento al cambiar de app o cerrar ventanas recientes."
                                    },
                                    fontSize = 11.sp,
                                    color = if (isTurboActive) Color(0xFF80F0FF) else TextSecondaryDark,
                                    lineHeight = 15.sp
                                )
                            }
                        }
                    }
                }

                // Modes Title
                item {
                    Text(
                        text = "Modos de Rendimiento y Batería",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryDark,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                // Power & Turbo Modes
                items(BatteryMode.entries.size) { index ->
                    val mode = BatteryMode.entries[index]
                    val isSelected = batteryInfo.activeMode == mode
                    val isTurbo = mode == BatteryMode.TURBO

                    val activeBorderColor = if (isTurbo) Color(0xFF00E5FF) else TecnoAmberWarning
                    val activeTextColor = if (isTurbo) Color(0xFF00E5FF) else TecnoAmberWarning

                    Box(
                        modifier = Modifier
                            .testTag("battery_mode_${mode.name}")
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (isSelected) TecnoNavyCardBorder.copy(alpha = 0.5f) else TecnoNavyCard)
                            .border(
                                width = if (isSelected) 1.5.dp else 1.dp,
                                color = if (isSelected) activeBorderColor else TecnoNavyCardBorder,
                                shape = RoundedCornerShape(16.dp)
                            )
                            .clickable { onSelectMode(mode) }
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = mode.label,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) activeTextColor else TextPrimaryDark
                                    )
                                    if (isTurbo) {
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(Color(0xFF7C4DFF).copy(alpha = 0.25f))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = "MAX CPU/GPU",
                                                fontSize = 9.sp,
                                                fontWeight = FontWeight.ExtraBold,
                                                color = Color(0xFF00E5FF)
                                            )
                                        }
                                    } else if (mode.extraHours > 0) {
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(TecnoGreenSuccess.copy(alpha = 0.15f))
                                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = "+${String.format("%.1f", mode.extraHours)}h",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = TecnoGreenSuccess
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = mode.description,
                                    fontSize = 11.sp,
                                    color = TextSecondaryDark
                                )
                            }

                            if (isSelected) {
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(activeBorderColor),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Activo",
                                        tint = Color.Black,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                // Power Optimization Toggles
                item {
                    Text(
                        text = "Ajustes de Ahorro Rápido",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryDark,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(TecnoNavyCard)
                            .border(1.dp, TecnoNavyCardBorder, RoundedCornerShape(16.dp))
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        SettingToggleRow(
                            icon = Icons.Default.WbSunny,
                            title = "Brillo Inteligente Adaptativo",
                            checked = optimizeBrightness,
                            onCheckedChange = { optimizeBrightness = it }
                        )

                        SettingToggleRow(
                            icon = Icons.Default.HourglassBottom,
                            title = "Suspender Pantalla a 15s",
                            checked = optimizeTimeout,
                            onCheckedChange = { optimizeTimeout = it }
                        )

                        SettingToggleRow(
                            icon = Icons.Default.Vibration,
                            title = "Desactivar Vibración Háptica",
                            checked = optimizeHaptics,
                            onCheckedChange = { optimizeHaptics = it }
                        )

                        SettingToggleRow(
                            icon = Icons.Default.DarkMode,
                            title = "Modo Oscuro Permanente HiOS",
                            checked = optimizeDarkMode,
                            onCheckedChange = { optimizeDarkMode = it }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DiagnosticChip(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(TecnoNavyCard)
            .border(1.dp, TecnoNavyCardBorder, RoundedCornerShape(12.dp))
            .padding(10.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = label,
                fontSize = 10.sp,
                color = TextSecondaryDark
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TecnoCyanGlow
            )
        }
    }
}

@Composable
private fun SettingToggleRow(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = TecnoCyanGlow,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium,
                color = TextPrimaryDark
            )
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = TecnoAmberWarning,
                uncheckedThumbColor = TextSecondaryDark,
                uncheckedTrackColor = TecnoNavyCardBorder
            )
        )
    }
}
