package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.formatBytes
import com.example.ui.theme.TecnoCyanGlow
import com.example.ui.theme.TecnoGreenSuccess
import com.example.ui.theme.TecnoNavyDark
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private data class VortexParticle(
    val initialRadiusRatio: Float,
    val baseAngle: Double,
    val speed: Float,
    val size: Float,
    val color: Color
)

@Composable
fun JunkCleanAnimation(
    totalBytesToClean: Long,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "junkCleanAnimation")

    // Continuous vortex rotation
    val vortexAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "vortexRotation"
    )

    // Pulse for trash shredder aura
    val pulseAura by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 1.2f,
        animationSpec = infiniteRepeatable(
            animation = tween(500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "auraPulse"
    )

    // Suction inward phase 0..1
    val suctionPhase by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 0.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1100, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "suction"
    )

    // Overall progress 0..1
    val progress by infiniteTransition.animateFloat(
        initialValue = 0.1f,
        targetValue = 0.98f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "overallProgress"
    )

    val particles = remember {
        List(28) { index ->
            val angle = (index * (360.0 / 28.0) + Random.nextDouble(-12.0, 12.0)) * Math.PI / 180.0
            VortexParticle(
                initialRadiusRatio = Random.nextFloat() * 0.4f + 0.6f,
                baseAngle = angle,
                speed = Random.nextFloat() * 0.6f + 0.7f,
                size = Random.nextFloat() * 4.5f + 3f,
                color = if (index % 2 == 0) TecnoGreenSuccess else TecnoCyanGlow
            )
        }
    }

    val currentFreedBytes = (totalBytesToClean * progress).toLong().coerceAtLeast(1024L * 1024L * 80L)

    val stageText = when {
        progress < 0.35f -> "Eliminando caché de aplicaciones y vistas previas..."
        progress < 0.70f -> "Borrando archivos residuales y paquetes obsoletos..."
        else -> "Purgando registros temporales y liberando almacenamiento..."
    }

    Box(
        modifier = modifier
            .testTag("junk_clean_animation_overlay")
            .fillMaxSize()
            .background(TecnoNavyDark.copy(alpha = 0.95f)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(28.dp)
        ) {
            // Suction Vortex Canvas
            Box(
                modifier = Modifier.size(240.dp),
                contentAlignment = Alignment.Center
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val center = Offset(size.width / 2, size.height / 2)
                    val maxRadius = (size.minDimension / 2) - 25.dp.toPx()

                    // Outer green spiral arc
                    drawArc(
                        brush = Brush.sweepGradient(
                            listOf(TecnoGreenSuccess, TecnoCyanGlow, Color.Transparent, TecnoGreenSuccess)
                        ),
                        startAngle = vortexAngle,
                        sweepAngle = 270f,
                        useCenter = false,
                        topLeft = Offset(center.x - maxRadius, center.y - maxRadius),
                        size = androidx.compose.ui.geometry.Size(maxRadius * 2, maxRadius * 2),
                        style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round)
                    )

                    // Secondary inner rotating ring
                    drawArc(
                        color = TecnoGreenSuccess.copy(alpha = 0.4f),
                        startAngle = -vortexAngle * 1.3f,
                        sweepAngle = 160f,
                        useCenter = false,
                        topLeft = Offset(center.x - maxRadius + 14.dp.toPx(), center.y - maxRadius + 14.dp.toPx()),
                        size = androidx.compose.ui.geometry.Size((maxRadius - 14.dp.toPx()) * 2, (maxRadius - 14.dp.toPx()) * 2),
                        style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                    )

                    // Inward spiraling particles
                    particles.forEach { p ->
                        val currentRadiusRatio = (suctionPhase * p.initialRadiusRatio * p.speed) % 1f
                        val currentRadius = maxRadius * currentRadiusRatio
                        val spiralOffsetAngle = (1f - currentRadiusRatio) * 3.5 // spiral twisting
                        val angle = p.baseAngle + spiralOffsetAngle

                        val px = (center.x + currentRadius * cos(angle)).toFloat()
                        val py = (center.y + currentRadius * sin(angle)).toFloat()

                        drawCircle(
                            color = p.color.copy(alpha = (currentRadiusRatio * 0.9f).coerceIn(0.2f, 1f)),
                            radius = p.size,
                            center = Offset(px, py)
                        )
                    }

                    // Center glowing aura
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(TecnoGreenSuccess.copy(alpha = 0.35f * pulseAura), Color.Transparent)
                        ),
                        radius = maxRadius * 0.55f * pulseAura,
                        center = center
                    )
                }

                // Center Trash Disintegrator Icon
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF00C853), Color(0xFF69F0AE))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = "Limpiando Basura",
                        tint = Color.Black,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "LIMPIANDO BASURA",
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                color = TecnoGreenSuccess,
                letterSpacing = 2.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Liberado: ${formatBytes(currentFreedBytes)}",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = TecnoCyanGlow
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = stageText,
                fontSize = 12.sp,
                color = TextSecondaryDark,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(20.dp))

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth(0.75f)
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = TecnoGreenSuccess,
                trackColor = TecnoNavyDark.copy(alpha = 0.6f)
            )
        }
    }
}
