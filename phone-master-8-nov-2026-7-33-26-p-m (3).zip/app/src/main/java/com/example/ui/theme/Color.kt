package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Tecno HiOS Phone Master signature palette
val TecnoNavyDark = Color(0xFF0A1222)
val TecnoNavyCard = Color(0xFF13223E)
val TecnoNavyCardBorder = Color(0xFF1F3660)
val TecnoNavyCardElevated = Color(0xFF182C50)

val TecnoBluePrimary = Color(0xFF0075FF)
val TecnoCyanGlow = Color(0xFF00E5FF)
val TecnoCyanLight = Color(0xFF80F0FF)

val TecnoGreenSuccess = Color(0xFF00E676)
val TecnoAmberWarning = Color(0xFFFFAB00)
val TecnoRedDanger = Color(0xFFFF5252)

val TextPrimaryDark = Color(0xFFF0F4F8)
val TextSecondaryDark = Color(0xFF94A3B8)
val TextTertiaryDark = Color(0xFF64748B)

// Light theme equivalents
val TecnoLightBg = Color(0xFFF4F7FC)
val TecnoLightCard = Color(0xFFFFFFFF)
val TecnoLightCardBorder = Color(0xFFE2E8F0)
val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF475569)
