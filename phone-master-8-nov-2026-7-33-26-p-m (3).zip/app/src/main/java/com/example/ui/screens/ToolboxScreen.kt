package com.example.ui.screens

import android.content.Context
import android.media.ToneGenerator
import android.media.AudioManager
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.repository.SystemOptimizerRepository
import com.example.ui.components.PhoneMasterTopBar
import com.example.ui.theme.TecnoAmberWarning
import com.example.ui.theme.TecnoBluePrimary
import com.example.ui.theme.TecnoCyanGlow
import com.example.ui.theme.TecnoGreenSuccess
import com.example.ui.theme.TecnoNavyCard
import com.example.ui.theme.TecnoNavyCardBorder
import com.example.ui.theme.TecnoNavyDark
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.ui.viewmodel.Screen

private data class ToolItem(
    val id: String,
    val title: String,
    val description: String,
    val icon: ImageVector,
    val color: Color,
    val badge: String = ""
)

@Composable
fun ToolboxScreen(
    networkInfo: Map<String, String>,
    isGameMode: Boolean,
    onToggleGameMode: () -> Unit,
    onNavigate: (Screen) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val context = LocalContext.current
    val repository = remember { SystemOptimizerRepository(context) }

    var showGameDialog by remember { mutableStateOf(false) }
    var showHardwareDialog by remember { mutableStateOf(false) }
    var showNetworkDialog by remember { mutableStateOf(false) }
    var showSecurityDialog by remember { mutableStateOf(false) }

    val tools = listOf(
        ToolItem(
            id = "game_booster",
            title = "Acelerador de Juegos",
            description = "Game Space y optimización GPU",
            icon = Icons.Default.Gamepad,
            color = Color(0xFF00E5FF),
            badge = if (isGameMode) "ACTIVO" else ""
        ),
        ToolItem(
            id = "app_manager",
            title = "Gestor de Aplicaciones",
            description = "Desinstala y administra apps",
            icon = Icons.Default.Apps,
            color = Color(0xFF00C853)
        ),
        ToolItem(
            id = "hardware_check",
            title = "Diagnóstico Hardware",
            description = "Test de vibrador, pantalla y audio",
            icon = Icons.Default.Vibration,
            color = Color(0xFFFF9100)
        ),
        ToolItem(
            id = "network_monitor",
            title = "Monitor de Red HiOS",
            description = "Velocidad de descarga y latencia",
            icon = Icons.Default.NetworkCheck,
            color = Color(0xFF00B0FF)
        ),
        ToolItem(
            id = "deep_clean",
            title = "Limpieza Profunda",
            description = "Archivos grandes y descargas viejas",
            icon = Icons.Default.CleaningServices,
            color = Color(0xFF69F0AE)
        ),
        ToolItem(
            id = "security_vault",
            title = "Bóveda y Seguridad",
            description = "Protección de privacidad y apps",
            icon = Icons.Default.Security,
            color = Color(0xFF7C4DFF),
            badge = "PROTEGIDO"
        ),
        ToolItem(
            id = "app_hibernation",
            title = "Congelador (Freezer)",
            description = "Hibernación de apps de alto consumo",
            icon = Icons.Default.AcUnit,
            color = Color(0xFF00E5FF),
            badge = "AHORRO"
        ),
        ToolItem(
            id = "audio_equalizer",
            title = "Ecualizador y Sonido",
            description = "Bajos potentes y mejora de volumen",
            icon = Icons.Default.GraphicEq,
            color = Color(0xFF00C853),
            badge = "DTS AUDIO"
        )
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(TecnoNavyDark)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            PhoneMasterTopBar(
                title = "Caja de Herramientas",
                subtitle = "Suite Tecno HiOS",
                showBackButton = true,
                onBackClick = onBack
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 10.dp, bottom = 90.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(tools, key = { it.id }) { tool ->
                    ToolGridItem(
                        tool = tool,
                        onClick = {
                            when (tool.id) {
                                "game_booster" -> showGameDialog = true
                                "app_manager" -> onNavigate(Screen.APP_MANAGER)
                                "hardware_check" -> showHardwareDialog = true
                                "network_monitor" -> showNetworkDialog = true
                                "deep_clean" -> onNavigate(Screen.JUNK_CLEANER)
                                "security_vault" -> showSecurityDialog = true
                                "app_hibernation" -> onNavigate(Screen.APP_HIBERNATION)
                                "audio_equalizer" -> onNavigate(Screen.EQUALIZER)
                            }
                        }
                    )
                }
            }
        }

        // Modals
        if (showGameDialog) {
            GameBoosterDialog(
                isGameMode = isGameMode,
                onToggleGameMode = onToggleGameMode,
                onDismiss = { showGameDialog = false }
            )
        }

        if (showHardwareDialog) {
            HardwareDiagnosticsDialog(
                onTestVibration = { repository.triggerVibration() },
                onDismiss = { showHardwareDialog = false }
            )
        }

        if (showNetworkDialog) {
            NetworkMonitorDialog(
                networkInfo = networkInfo,
                onDismiss = { showNetworkDialog = false }
            )
        }

        if (showSecurityDialog) {
            SecurityDialog(onDismiss = { showSecurityDialog = false })
        }
    }
}

@Composable
private fun ToolGridItem(
    tool: ToolItem,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .testTag("tool_card_${tool.id}")
            .height(145.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(TecnoNavyCard)
            .border(1.dp, TecnoNavyCardBorder, RoundedCornerShape(18.dp))
            .clickable { onClick() }
            .padding(14.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(tool.color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = tool.icon,
                        contentDescription = tool.title,
                        tint = tool.color,
                        modifier = Modifier.size(24.dp)
                    )
                }

                if (tool.badge.isNotEmpty()) {
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(tool.color.copy(alpha = 0.2f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = tool.badge,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = tool.color
                        )
                    }
                }
            }

            Column {
                Text(
                    text = tool.title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryDark,
                    maxLines = 1
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = tool.description,
                    fontSize = 10.sp,
                    color = TextSecondaryDark,
                    maxLines = 2,
                    lineHeight = 13.sp
                )
            }
        }
    }
}

@Composable
private fun GameBoosterDialog(
    isGameMode: Boolean,
    onToggleGameMode: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .testTag("game_booster_dialog")
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(TecnoNavyCard)
                .border(1.dp, TecnoCyanGlow.copy(alpha = 0.4f), RoundedCornerShape(22.dp))
                .padding(20.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Gamepad,
                            contentDescription = null,
                            tint = TecnoCyanGlow,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Game Space HiOS",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Cerrar", tint = TextSecondaryDark)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(TecnoNavyDark)
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Aceleración de Juegos",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark
                            )
                            Text(
                                text = "Prioriza CPU/GPU y latencia baja",
                                fontSize = 11.sp,
                                color = TextSecondaryDark
                            )
                        }

                        Switch(
                            checked = isGameMode,
                            onCheckedChange = { onToggleGameMode() },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.Black,
                                checkedTrackColor = TecnoCyanGlow
                            )
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "• Bloqueo inteligente de notificaciones flotantes",
                    fontSize = 11.sp,
                    color = TextSecondaryDark
                )
                Text(
                    text = "• Bloqueo de brillo de pantalla durante la partida",
                    fontSize = 11.sp,
                    color = TextSecondaryDark
                )
                Text(
                    text = "• Limpieza de RAM previa al lanzamiento de juegos",
                    fontSize = 11.sp,
                    color = TextSecondaryDark
                )

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TecnoBluePrimary)
                ) {
                    Text("CERRAR", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun HardwareDiagnosticsDialog(
    onTestVibration: () -> Unit,
    onDismiss: () -> Unit
) {
    var screenTestColor by remember { mutableStateOf<Color?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .testTag("hardware_check_dialog")
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(TecnoNavyCard)
                .border(1.dp, TecnoAmberWarning.copy(alpha = 0.4f), RoundedCornerShape(22.dp))
                .padding(20.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Vibration,
                            contentDescription = null,
                            tint = TecnoAmberWarning,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Diagnóstico de Hardware",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Cerrar", tint = TextSecondaryDark)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Test 1: Vibration
                Button(
                    onClick = onTestVibration,
                    modifier = Modifier
                        .testTag("test_vibration_button")
                        .fillMaxWidth()
                        .height(46.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TecnoNavyDark)
                ) {
                    Icon(Icons.Default.Vibration, contentDescription = null, tint = TecnoAmberWarning)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Probar Motor de Vibración Háptica", fontSize = 12.sp, color = TextPrimaryDark)
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Test 2: Speaker Tone
                Button(
                    onClick = {
                        try {
                            val toneGen = ToneGenerator(AudioManager.STREAM_MUSIC, 80)
                            toneGen.startTone(ToneGenerator.TONE_CDMA_PIP, 250)
                        } catch (_: Exception) {}
                    },
                    modifier = Modifier
                        .testTag("test_speaker_button")
                        .fillMaxWidth()
                        .height(46.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TecnoNavyDark)
                ) {
                    Icon(Icons.Default.VolumeUp, contentDescription = null, tint = TecnoCyanGlow)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Probar Altavoz del Teléfono", fontSize = 12.sp, color = TextPrimaryDark)
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Test 3: Screen Pixel Colors
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { screenTestColor = Color.Red },
                        modifier = Modifier.weight(1f).height(36.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Red),
                        shape = RoundedCornerShape(8.dp)
                    ) { Text("Rojo", fontSize = 11.sp, color = Color.White) }

                    Button(
                        onClick = { screenTestColor = Color.Green },
                        modifier = Modifier.weight(1f).height(36.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Green),
                        shape = RoundedCornerShape(8.dp)
                    ) { Text("Verde", fontSize = 11.sp, color = Color.Black) }

                    Button(
                        onClick = { screenTestColor = Color.Blue },
                        modifier = Modifier.weight(1f).height(36.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Blue),
                        shape = RoundedCornerShape(8.dp)
                    ) { Text("Azul", fontSize = 11.sp, color = Color.White) }
                }

                if (screenTestColor != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(60.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(screenTestColor!!)
                            .clickable { screenTestColor = null },
                        contentAlignment = Alignment.Center
                    ) {
                        Text("Toca para cerrar prueba", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TecnoBluePrimary)
                ) {
                    Text("FINALIZAR PRUEBA", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun NetworkMonitorDialog(
    networkInfo: Map<String, String>,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .testTag("network_monitor_dialog")
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(TecnoNavyCard)
                .border(1.dp, TecnoCyanGlow.copy(alpha = 0.4f), RoundedCornerShape(22.dp))
                .padding(20.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.NetworkCheck,
                            contentDescription = null,
                            tint = TecnoCyanGlow,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Monitor de Tráfico y Red",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Cerrar", tint = TextSecondaryDark)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                networkInfo.forEach { (key, value) ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 5.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = key.replaceFirstChar { it.uppercase() },
                            fontSize = 12.sp,
                            color = TextSecondaryDark
                        )
                        Text(
                            text = value,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = TecnoCyanGlow
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = TecnoBluePrimary)
                ) {
                    Text("CERRAR", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun SecurityDialog(onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .testTag("security_vault_dialog")
                .fillMaxWidth()
                .clip(RoundedCornerShape(22.dp))
                .background(TecnoNavyCard)
                .border(1.dp, Color(0xFF7C4DFF).copy(alpha = 0.4f), RoundedCornerShape(22.dp))
                .padding(20.dp)
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = Color(0xFF7C4DFF),
                    modifier = Modifier.size(48.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "Bóveda de Privacidad HiOS",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryDark
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "Escaneo de permisos y aplicaciones finalizado con éxito. Sin amenazas detectadas.",
                    fontSize = 12.sp,
                    color = TextSecondaryDark,
                    lineHeight = 16.sp
                )
                Spacer(modifier = Modifier.height(18.dp))
                Button(
                    onClick = onDismiss,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C4DFF))
                ) {
                    Text("ENTENDIDO", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
