package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = TecnoCyanGlow,
    onPrimary = Color.Black,
    primaryContainer = TecnoBluePrimary,
    onPrimaryContainer = Color.White,
    secondary = TecnoCyanLight,
    onSecondary = Color.Black,
    background = TecnoNavyDark,
    onBackground = TextPrimaryDark,
    surface = TecnoNavyCard,
    onSurface = TextPrimaryDark,
    surfaceVariant = TecnoNavyCardElevated,
    onSurfaceVariant = TextSecondaryDark,
    outline = TecnoNavyCardBorder,
    error = TecnoRedDanger,
    onError = Color.White
)

private val LightColorScheme = lightColorScheme(
    primary = TecnoBluePrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCEBFF),
    onPrimaryContainer = TecnoBluePrimary,
    secondary = TecnoCyanGlow,
    onSecondary = Color.Black,
    background = TecnoLightBg,
    onBackground = TextPrimaryLight,
    surface = TecnoLightCard,
    onSurface = TextPrimaryLight,
    surfaceVariant = Color(0xFFEDF2F7),
    onSurfaceVariant = TextSecondaryLight,
    outline = TecnoLightCardBorder,
    error = TecnoRedDanger,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true, // Default to Tecno HiOS high-tech dark theme
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
