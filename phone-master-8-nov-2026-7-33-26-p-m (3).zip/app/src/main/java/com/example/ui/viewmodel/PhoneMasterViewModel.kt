package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.BatteryInfo
import com.example.data.model.BatteryMode
import com.example.data.model.CpuThermalInfo
import com.example.data.model.InstalledAppItem
import com.example.data.model.JunkCategory
import com.example.data.model.OptimizationResult
import com.example.data.model.RamInfo
import com.example.data.model.RunningAppTask
import com.example.data.model.StorageInfo
import com.example.data.model.HibernationAppItem
import com.example.data.repository.SystemOptimizerRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

import com.example.data.audio.AudioEnhancerManager
import com.example.data.model.AudioEnhancerState
import com.example.data.model.EqualizerPreset

enum class Screen {
    HOME,
    JUNK_CLEANER,
    PHONE_BOOST,
    CPU_COOLER,
    BATTERY_LAB,
    TOOLBOX,
    APP_MANAGER,
    APP_HIBERNATION,
    EQUALIZER
}

data class PhoneMasterUiState(
    val currentScreen: Screen = Screen.HOME,
    val healthScore: Int = 78,
    val isOptimized: Boolean = false,
    val ramInfo: RamInfo = RamInfo(),
    val storageInfo: StorageInfo = StorageInfo(),
    val cpuInfo: CpuThermalInfo = CpuThermalInfo(),
    val batteryInfo: BatteryInfo = BatteryInfo(),

    // Junk Cleaner State
    val junkCategories: List<JunkCategory> = emptyList(),
    val isScanningJunk: Boolean = false,
    val isCleaningJunk: Boolean = false,

    // Boost State
    val runningTasks: List<RunningAppTask> = emptyList(),
    val isBoostingRam: Boolean = false,

    // CPU Cooler State
    val isCoolingCpu: Boolean = false,

    // Full 100% 1-Tap Optimization State
    val isOptimizingAll: Boolean = false,
    val optimizationStepText: String = "",
    val optimizationProgress: Float = 0f,
    val lastResult: OptimizationResult? = null,
    val showResultDialog: Boolean = false,

    // Hibernation State
    val hibernationApps: List<HibernationAppItem> = emptyList(),
    val isScanningHibernation: Boolean = false,
    val isHibernating: Boolean = false,

    // Toolbox State
    val installedApps: List<InstalledAppItem> = emptyList(),
    val isLoadingApps: Boolean = false,
    val networkInfo: Map<String, String> = emptyMap(),
    val isGameModeEnabled: Boolean = false,
    val isTurboRunning: Boolean = false,
    val audioState: AudioEnhancerState = AudioEnhancerState()
)

class PhoneMasterViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = SystemOptimizerRepository(application.applicationContext)
    private val audioManager = AudioEnhancerManager(application.applicationContext)

    private val _uiState = MutableStateFlow(PhoneMasterUiState())
    val uiState: StateFlow<PhoneMasterUiState> = _uiState.asStateFlow()

    init {
        refreshTelemetry()
        loadJunkCategories()
        loadRunningTasks()
        loadHibernationApps()

        val initialAudio = audioManager.initializeAudioFx()
        _uiState.update { it.copy(audioState = initialAudio) }

        viewModelScope.launch {
            com.example.service.PhoneMasterTurboService.isTurboRunning.collect { running ->
                _uiState.update { state ->
                    state.copy(
                        isTurboRunning = running,
                        batteryInfo = if (running && state.batteryInfo.activeMode != BatteryMode.TURBO) {
                            state.batteryInfo.copy(activeMode = BatteryMode.TURBO)
                        } else state.batteryInfo
                    )
                }
            }
        }
    }

    fun navigateTo(screen: Screen) {
        _uiState.update { it.copy(currentScreen = screen) }
        if (screen == Screen.APP_MANAGER && _uiState.value.installedApps.isEmpty()) {
            loadInstalledApps()
        }
        if (screen == Screen.APP_HIBERNATION && _uiState.value.hibernationApps.isEmpty()) {
            loadHibernationApps()
        }
        if (screen == Screen.TOOLBOX) {
            refreshNetworkInfo()
        }
    }

    fun refreshTelemetry() {
        val ram = repository.getRamInfo()
        val storage = repository.getStorageInfo()
        val battery = repository.getBatteryInfo()
        val cpu = repository.getCpuThermalInfo()
        val score = repository.calculateHealthScore(ram, cpu, battery)

        _uiState.update {
            it.copy(
                ramInfo = ram,
                storageInfo = storage,
                batteryInfo = battery,
                cpuInfo = cpu,
                healthScore = score
            )
        }
    }

    fun loadJunkCategories() {
        viewModelScope.launch {
            _uiState.update { it.copy(isScanningJunk = true) }
            val categories = repository.scanJunkFiles()
            _uiState.update {
                it.copy(
                    junkCategories = categories,
                    isScanningJunk = false
                )
            }
        }
    }

    fun toggleJunkCategory(categoryId: String) {
        _uiState.update { state ->
            val updated = state.junkCategories.map { cat ->
                if (cat.id == categoryId) cat.copy(isSelected = !cat.isSelected) else cat
            }
            state.copy(junkCategories = updated)
        }
    }

    fun selectAllJunk(selected: Boolean) {
        _uiState.update { state ->
            val updated = state.junkCategories.map { it.copy(isSelected = selected) }
            state.copy(junkCategories = updated)
        }
    }

    fun cleanJunk() {
        viewModelScope.launch {
            _uiState.update { it.copy(isCleaningJunk = true) }
            delay(2200)
            val freedBytes = repository.cleanJunk(_uiState.value.junkCategories)
            val freedMb = freedBytes / (1024 * 1024)

            // Re-fetch categories and storage
            val refreshedCategories = repository.scanJunkFiles().map {
                it.copy(sizeBytes = 0L, items = emptyList())
            }
            refreshTelemetry()

            _uiState.update {
                it.copy(
                    isCleaningJunk = false,
                    junkCategories = refreshedCategories,
                    lastResult = OptimizationResult(
                        ramFreedMb = 0L,
                        junkFreedMb = freedMb,
                        coolingDegrees = 0f,
                        batteryExtraHours = 0f,
                        previousScore = it.healthScore,
                        newScore = (it.healthScore + 12).coerceAtMost(100)
                    ),
                    showResultDialog = true
                )
            }
        }
    }

    fun loadRunningTasks() {
        viewModelScope.launch {
            val tasks = repository.getRunningTasks()
            _uiState.update { it.copy(runningTasks = tasks) }
        }
    }

    fun toggleTask(packageName: String) {
        _uiState.update { state ->
            val updated = state.runningTasks.map { task ->
                if (task.packageName == packageName) task.copy(isSelected = !task.isSelected) else task
            }
            state.copy(runningTasks = updated)
        }
    }

    fun boostRam() {
        viewModelScope.launch {
            _uiState.update { it.copy(isBoostingRam = true) }
            delay(2200)
            val freedMb = repository.boostPhone(_uiState.value.runningTasks)
            refreshTelemetry()

            _uiState.update {
                it.copy(
                    isBoostingRam = false,
                    runningTasks = it.runningTasks.map { task -> task.copy(ramUsageMb = task.ramUsageMb / 3) },
                    lastResult = OptimizationResult(
                        ramFreedMb = freedMb,
                        junkFreedMb = 0L,
                        coolingDegrees = 1.5f,
                        batteryExtraHours = 1.2f,
                        previousScore = it.healthScore,
                        newScore = (it.healthScore + 15).coerceAtMost(100)
                    ),
                    showResultDialog = true
                )
            }
        }
    }

    fun coolCpu() {
        viewModelScope.launch {
            _uiState.update { it.copy(isCoolingCpu = true) }
            val degrees = repository.coolCpu()
            refreshTelemetry()

            _uiState.update {
                it.copy(
                    isCoolingCpu = false,
                    lastResult = OptimizationResult(
                        ramFreedMb = 280L,
                        junkFreedMb = 0L,
                        coolingDegrees = degrees,
                        batteryExtraHours = 1.0f,
                        previousScore = it.healthScore,
                        newScore = (it.healthScore + 10).coerceAtMost(100)
                    ),
                    showResultDialog = true
                )
            }
        }
    }

    fun setBatteryMode(mode: BatteryMode) {
        repository.setBatteryMode(mode)
        refreshTelemetry()
    }

    fun toggleTurboMode() {
        val current = _uiState.value.batteryInfo.activeMode
        if (current == BatteryMode.TURBO) {
            setBatteryMode(BatteryMode.NORMAL)
        } else {
            setBatteryMode(BatteryMode.TURBO)
        }
    }

    /**
     * Master 1-Tap 100% Full System Optimization
     * Simulates and performs all Phone Master stages with realistic progressive steps
     */
    fun optimizeEverything100() {
        viewModelScope.launch {
            val startScore = _uiState.value.healthScore
            _uiState.update {
                it.copy(
                    isOptimizingAll = true,
                    optimizationProgress = 0.05f,
                    optimizationStepText = "Iniciando diagnóstico profundo de HiOS..."
                )
            }
            delay(500)

            // Step 1: Scan & Free RAM
            _uiState.update {
                it.copy(
                    optimizationProgress = 0.25f,
                    optimizationStepText = "Acelerando RAM y cerrando procesos en segundo plano..."
                )
            }
            val freedRam = repository.boostPhone(_uiState.value.runningTasks)
            delay(650)

            // Step 2: Clean System & App Cache
            _uiState.update {
                it.copy(
                    optimizationProgress = 0.55f,
                    optimizationStepText = "Limpiando archivos de caché residual y datos basura..."
                )
            }
            val freedJunkBytes = repository.cleanJunk(_uiState.value.junkCategories)
            val freedJunkMb = freedJunkBytes / (1024 * 1024)
            delay(650)

            // Step 3: CPU & Thermal stabilization
            _uiState.update {
                it.copy(
                    optimizationProgress = 0.80f,
                    optimizationStepText = "Enfriando CPU/GPU y equilibrando frecuencia de reloj..."
                )
            }
            val cooledDegrees = repository.coolCpu()
            delay(600)

            // Step 4: Battery & Power configuration
            _uiState.update {
                it.copy(
                    optimizationProgress = 0.95f,
                    optimizationStepText = "Calibrando perfiles de energía de Power Marathon..."
                )
            }
            repository.setBatteryMode(BatteryMode.SMART_SAVER)
            delay(400)

            // Completed! Re-fetch telemetry
            refreshTelemetry()

            val result = OptimizationResult(
                ramFreedMb = freedRam.coerceAtLeast(820L),
                junkFreedMb = freedJunkMb.coerceAtLeast(640L),
                coolingDegrees = cooledDegrees,
                batteryExtraHours = 3.5f,
                previousScore = startScore,
                newScore = 100
            )

            _uiState.update {
                it.copy(
                    isOptimizingAll = false,
                    optimizationProgress = 1.0f,
                    optimizationStepText = "¡Optimización 100% completada con éxito!",
                    healthScore = 100,
                    isOptimized = true,
                    lastResult = result,
                    showResultDialog = true,
                    runningTasks = it.runningTasks.map { task -> task.copy(ramUsageMb = task.ramUsageMb / 4) }
                )
            }
        }
    }

    fun dismissResultDialog() {
        _uiState.update { it.copy(showResultDialog = false) }
    }

    fun loadInstalledApps() {
        viewModelScope.launch {
            _uiState.update { it.copy(isLoadingApps = true) }
            val apps = repository.getInstalledApps()
            _uiState.update { it.copy(installedApps = apps, isLoadingApps = false) }
        }
    }

    fun refreshNetworkInfo() {
        val net = repository.getNetworkInfo()
        _uiState.update { it.copy(networkInfo = net) }
    }

    fun toggleGameMode() {
        repository.triggerVibration()
        _uiState.update { it.copy(isGameModeEnabled = !it.isGameModeEnabled) }
    }

    fun loadHibernationApps() {
        viewModelScope.launch {
            _uiState.update { it.copy(isScanningHibernation = true) }
            val apps = repository.getHibernationApps()
            _uiState.update { it.copy(hibernationApps = apps, isScanningHibernation = false) }
        }
    }

    fun toggleHibernationSelect(packageName: String) {
        _uiState.update { state ->
            val updated = state.hibernationApps.map { app ->
                if (app.packageName == packageName && !app.isHibernated) {
                    app.copy(isSelected = !app.isSelected)
                } else app
            }
            state.copy(hibernationApps = updated)
        }
    }

    fun selectAllHibernation(selected: Boolean) {
        _uiState.update { state ->
            val updated = state.hibernationApps.map {
                if (!it.isHibernated) it.copy(isSelected = selected) else it
            }
            state.copy(hibernationApps = updated)
        }
    }

    fun hibernateSelectedApps() {
        viewModelScope.launch {
            _uiState.update { it.copy(isHibernating = true) }
            delay(1600)
            val selected = _uiState.value.hibernationApps.filter { it.isSelected && !it.isHibernated }
            val pkgs = selected.map { it.packageName }
            repository.hibernateApps(pkgs)

            val updated = _uiState.value.hibernationApps.map { app ->
                if (pkgs.contains(app.packageName)) {
                    app.copy(isHibernated = true, isSelected = false)
                } else app
            }

            refreshTelemetry()

            val savedMah = selected.sumOf { it.estimatedMahDrain }
            _uiState.update {
                it.copy(
                    isHibernating = false,
                    hibernationApps = updated,
                    lastResult = OptimizationResult(
                        ramFreedMb = (selected.size * 180L).coerceAtLeast(360L),
                        junkFreedMb = 0L,
                        coolingDegrees = 1.2f,
                        batteryExtraHours = (savedMah / 110.0f).coerceAtLeast(1.5f),
                        previousScore = it.healthScore,
                        newScore = (it.healthScore + 8).coerceAtMost(100)
                    ),
                    showResultDialog = true
                )
            }
        }
    }

    fun hibernateSingleApp(packageName: String) {
        viewModelScope.launch {
            repository.hibernateApp(packageName)
            val updated = _uiState.value.hibernationApps.map { app ->
                if (app.packageName == packageName) {
                    app.copy(isHibernated = true, isSelected = false)
                } else app
            }
            _uiState.update { it.copy(hibernationApps = updated) }
            refreshTelemetry()
        }
    }

    fun wakeApp(packageName: String) {
        repository.wakeApp(packageName)
        val updated = _uiState.value.hibernationApps.map { app ->
            if (app.packageName == packageName) {
                app.copy(isHibernated = false, isSelected = false)
            } else app
        }
        _uiState.update { it.copy(hibernationApps = updated) }
        refreshTelemetry()
    }

    // Audio Equalizer & Sound Enhancement
    fun setAudioEqualizerEnabled(enabled: Boolean) {
        audioManager.setEnabled(enabled)
        _uiState.update { it.copy(audioState = it.audioState.copy(isEnabled = enabled)) }
        repository.triggerVibration()
    }

    fun selectAudioPreset(preset: EqualizerPreset) {
        audioManager.applyPreset(preset)
        val updatedBands = _uiState.value.audioState.bands.mapIndexed { index, band ->
            band.copy(currentLevelMdB = preset.bandLevels.getOrElse(index) { band.currentLevelMdB })
        }
        _uiState.update {
            it.copy(
                audioState = it.audioState.copy(
                    currentPresetId = preset.id,
                    bands = updatedBands,
                    bassBoostStrength = preset.bassBoost,
                    loudnessGainMdB = preset.loudnessGain
                )
            )
        }
        repository.triggerVibration()
    }

    fun setBandLevel(bandIndex: Int, levelMdB: Int) {
        audioManager.setBandLevel(bandIndex, levelMdB)
        val updatedBands = _uiState.value.audioState.bands.map { band ->
            if (band.index == bandIndex) band.copy(currentLevelMdB = levelMdB) else band
        }
        _uiState.update {
            it.copy(
                audioState = it.audioState.copy(
                    bands = updatedBands,
                    currentPresetId = "custom"
                )
            )
        }
    }

    fun setBassBoost(strength: Int) {
        audioManager.applyBassBoost(strength)
        _uiState.update {
            it.copy(audioState = it.audioState.copy(bassBoostStrength = strength, currentPresetId = "custom"))
        }
    }

    fun setLoudnessGain(gainMdB: Int) {
        audioManager.applyLoudnessGain(gainMdB)
        _uiState.update {
            it.copy(audioState = it.audioState.copy(loudnessGainMdB = gainMdB, currentPresetId = "custom"))
        }
    }

    fun setVirtualizer(strength: Int) {
        audioManager.applyVirtualizer(strength)
        _uiState.update {
            it.copy(audioState = it.audioState.copy(virtualizerStrength = strength))
        }
    }

    fun saveCustomPreset(name: String) {
        val currentLevels = _uiState.value.audioState.bands.map { it.currentLevelMdB }
        val newPreset = EqualizerPreset(
            id = "custom_${System.currentTimeMillis()}",
            name = name.ifBlank { "Mi Ecualizador Personalizado" },
            bandLevels = currentLevels,
            bassBoost = _uiState.value.audioState.bassBoostStrength,
            loudnessGain = _uiState.value.audioState.loudnessGainMdB,
            isCustom = true
        )
        val updatedCustoms = _uiState.value.audioState.customPresets + newPreset
        _uiState.update {
            it.copy(
                audioState = it.audioState.copy(
                    customPresets = updatedCustoms,
                    currentPresetId = newPreset.id
                )
            )
        }
        repository.triggerVibration()
    }

    fun deleteCustomPreset(presetId: String) {
        val updated = _uiState.value.audioState.customPresets.filter { it.id != presetId }
        _uiState.update {
            it.copy(audioState = it.audioState.copy(customPresets = updated))
        }
    }

    fun toggleTestAudio() {
        val isTesting = _uiState.value.audioState.isTestingTone
        if (isTesting) {
            audioManager.stopTestAudio()
            _uiState.update { it.copy(audioState = it.audioState.copy(isTestingTone = false)) }
        } else {
            _uiState.update { it.copy(audioState = it.audioState.copy(isTestingTone = true)) }
            viewModelScope.launch {
                audioManager.playTestAudio()
                kotlinx.coroutines.delay(3200)
                _uiState.update { it.copy(audioState = it.audioState.copy(isTestingTone = false)) }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        audioManager.release()
    }
}
