package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.DeviceThermostat
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.SdStorage
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.CoreFeatureCard
import com.example.ui.components.MetricCard
import com.example.ui.components.PhoneMasterTopBar
import com.example.ui.components.SpeedometerGauge
import com.example.ui.theme.TecnoAmberWarning
import com.example.ui.theme.TecnoBluePrimary
import com.example.ui.theme.TecnoCyanGlow
import com.example.ui.theme.TecnoGreenSuccess
import com.example.ui.theme.TecnoNavyCard
import com.example.ui.theme.TecnoNavyCardBorder
import com.example.ui.theme.TecnoNavyDark
import com.example.ui.theme.TecnoRedDanger
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.ui.viewmodel.PhoneMasterUiState
import com.example.ui.viewmodel.Screen

@Composable
fun HomeScreen(
    uiState: PhoneMasterUiState,
    onNavigate: (Screen) -> Unit,
    onOptimizeAll: () -> Unit,
    onRefresh: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(TecnoNavyDark)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            PhoneMasterTopBar(
                title = "Phone Master",
                subtitle = "Transsion Tecno HiOS",
                showBackButton = false,
                onRefreshClick = onRefresh
            )

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(bottom = 100.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Circular Gauge
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        SpeedometerGauge(
                            score = uiState.healthScore,
                            isOptimized = uiState.isOptimized
                        )
                    }
                }

                // Master 1-Tap 100% Boost Button
                item {
                    Button(
                        onClick = onOptimizeAll,
                        modifier = Modifier
                            .testTag("master_optimize_button")
                            .fillMaxWidth()
                            .height(56.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.Transparent
                        ),
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(TecnoBluePrimary, TecnoCyanGlow)
                                    ),
                                    shape = RoundedCornerShape(16.dp)
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.FlashOn,
                                    contentDescription = "Optimizar al 100%",
                                    tint = Color.Black,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (uiState.isOptimized) "OPTIMIZADO AL 100%" else "ACELERAR Y OPTIMIZAR AL 100%",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = Color.Black,
                                    letterSpacing = 0.5.sp
                                )
                            }
                        }
                    }
                }

                // RAM & Storage Metric Cards Row
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        MetricCard(
                            title = "Memoria RAM",
                            percent = uiState.ramInfo.usedPercent,
                            subtitle = "${uiState.ramInfo.usedGbFormatted} / ${uiState.ramInfo.totalGbFormatted}",
                            icon = Icons.Default.Memory,
                            accentColor = if (uiState.ramInfo.usedPercent > 80) TecnoRedDanger else TecnoCyanGlow,
                            testTag = "ram_metric_card",
                            onClick = { onNavigate(Screen.PHONE_BOOST) },
                            modifier = Modifier.weight(1f)
                        )

                        MetricCard(
                            title = "Almacenamiento",
                            percent = uiState.storageInfo.usedPercent,
                            subtitle = "${uiState.storageInfo.usedGbFormatted} / ${uiState.storageInfo.totalGbFormatted}",
                            icon = Icons.Default.SdStorage,
                            accentColor = Color(0xFF00E676),
                            testTag = "storage_metric_card",
                            onClick = { onNavigate(Screen.JUNK_CLEANER) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                // Section Header: Core Tools
                item {
                    Text(
                        text = "Funciones Principales",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimaryDark,
                        modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
                    )
                }

                // 2x2 Grid of Core Features
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            val totalJunkMb = uiState.junkCategories.sumOf { it.sizeBytes } / (1024 * 1024)
                            CoreFeatureCard(
                                title = "Limpiar Basura",
                                statusText = if (totalJunkMb > 0) "${totalJunkMb} MB detectados" else "Sistema limpio",
                                badgeText = if (totalJunkMb > 0) "Limpieza" else "Óptimo",
                                icon = Icons.Default.CleaningServices,
                                gradientColors = listOf(Color(0xFF00C853), Color(0xFF69F0AE)),
                                testTag = "junk_cleaner_card",
                                onClick = { onNavigate(Screen.JUNK_CLEANER) },
                                modifier = Modifier.weight(1f)
                            )

                            CoreFeatureCard(
                                title = "Acelerar Teléfono",
                                statusText = "${uiState.runningTasks.size} apps en 2do plano",
                                badgeText = "${uiState.ramInfo.usedPercent}% RAM",
                                icon = Icons.Default.RocketLaunch,
                                gradientColors = listOf(TecnoBluePrimary, TecnoCyanGlow),
                                testTag = "phone_boost_card",
                                onClick = { onNavigate(Screen.PHONE_BOOST) },
                                modifier = Modifier.weight(1f)
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            CoreFeatureCard(
                                title = "Enfriador CPU",
                                statusText = "${String.format("%.1f", uiState.cpuInfo.temperatureCelsius)}°C (${uiState.cpuInfo.statusText})",
                                badgeText = if (uiState.cpuInfo.isOverheated) "Caliente" else "Frío",
                                icon = Icons.Default.DeviceThermostat,
                                gradientColors = listOf(Color(0xFF00B0FF), Color(0xFF80D8FF)),
                                testTag = "cpu_cooler_card",
                                onClick = { onNavigate(Screen.CPU_COOLER) },
                                modifier = Modifier.weight(1f)
                            )

                            CoreFeatureCard(
                                title = "Ahorro de Batería",
                                statusText = "${uiState.batteryInfo.levelPercent}% • ${String.format("%.1f", uiState.batteryInfo.estimatedRemainingHours)}h rest.",
                                badgeText = uiState.batteryInfo.activeMode.label.take(8),
                                icon = Icons.Default.BatteryChargingFull,
                                gradientColors = listOf(Color(0xFFFF9100), Color(0xFFFFD54F)),
                                testTag = "battery_lab_card",
                                onClick = { onNavigate(Screen.BATTERY_LAB) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }

                // Banner: Tecno Toolbox Shortcut
                item {
                    Box(
                        modifier = Modifier
                            .testTag("toolbox_banner")
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(18.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(TecnoNavyCard, TecnoNavyCardBorder.copy(alpha = 0.6f))
                                )
                            )
                            .border(1.dp, TecnoCyanGlow.copy(alpha = 0.25f), RoundedCornerShape(18.dp))
                            .clickable { onNavigate(Screen.TOOLBOX) }
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(CircleShape)
                                        .background(TecnoCyanGlow.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Build,
                                        contentDescription = "Caja de Herramientas",
                                        tint = TecnoCyanGlow,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(14.dp))
                                Column {
                                    Text(
                                        text = "Caja de Herramientas HiOS",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimaryDark
                                    )
                                    Text(
                                        text = "Game Booster, Apps, Diagnóstico y Red",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Normal,
                                        color = TextSecondaryDark
                                    )
                                }
                            }

                            Icon(
                                imageVector = Icons.Default.ChevronRight,
                                contentDescription = "Ver herramientas",
                                tint = TecnoCyanGlow
                            )
                        }
                    }
                }
            }
        }
    }
}
