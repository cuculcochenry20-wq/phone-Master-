package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TecnoBluePrimary
import com.example.ui.theme.TecnoCyanGlow
import com.example.ui.theme.TecnoGreenSuccess
import com.example.ui.theme.TecnoNavyCardBorder
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SpeedometerGauge(
    score: Int,
    isOptimized: Boolean,
    modifier: Modifier = Modifier
) {
    val animatedScore by animateIntAsState(
        targetValue = score,
        animationSpec = tween(durationMillis = 900, easing = FastOutSlowInEasing),
        label = "scoreAnimation"
    )

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 0.9f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400),
            repeatMode = RepeatMode.Reverse
        ),
        label = "alpha"
    )

    val primaryColor = if (isOptimized || score >= 90) TecnoGreenSuccess else TecnoCyanGlow
    val secondaryColor = if (isOptimized || score >= 90) Color(0xFF00B0FF) else TecnoBluePrimary

    Box(
        modifier = modifier.size(240.dp),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(230.dp)) {
            val strokeWidth = 14.dp.toPx()
            val arcSize = size.width - strokeWidth
            val topLeft = Offset(strokeWidth / 2, strokeWidth / 2)

            // Background subtle circular track (240 degrees arc)
            drawArc(
                color = TecnoNavyCardBorder.copy(alpha = 0.5f),
                startAngle = 150f,
                sweepAngle = 240f,
                useCenter = false,
                topLeft = topLeft,
                size = Size(arcSize, arcSize),
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            // Active gradient arc based on score (0 - 100 maps to 0 - 240 deg)
            val sweep = (animatedScore / 100f) * 240f
            drawArc(
                brush = Brush.sweepGradient(
                    colors = listOf(secondaryColor, primaryColor, secondaryColor)
                ),
                startAngle = 150f,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = topLeft,
                size = Size(arcSize, arcSize),
                style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
            )

            // Inner glowing tick marks
            val center = Offset(size.width / 2, size.height / 2)
            val radius = (size.width / 2) - 24.dp.toPx()

            for (i in 0..24) {
                val angleDeg = 150f + (i * 10f)
                val angleRad = Math.toRadians(angleDeg.toDouble())
                val startRadius = radius - if (i % 4 == 0) 8.dp.toPx() else 4.dp.toPx()
                val tickColor = if (angleDeg <= 150f + sweep) primaryColor.copy(alpha = 0.8f) else Color.White.copy(alpha = 0.15f)

                val p1 = Offset(
                    (center.x + startRadius * cos(angleRad)).toFloat(),
                    (center.y + startRadius * sin(angleRad)).toFloat()
                )
                val p2 = Offset(
                    (center.x + radius * cos(angleRad)).toFloat(),
                    (center.y + radius * sin(angleRad)).toFloat()
                )
                drawLine(
                    color = tickColor,
                    start = p1,
                    end = p2,
                    strokeWidth = if (i % 4 == 0) 2.5.dp.toPx() else 1.2.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }
        }

        // Center Score display
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(top = 10.dp)
        ) {
            Text(
                text = "$animatedScore",
                fontSize = 58.sp,
                fontWeight = FontWeight.ExtraBold,
                color = TextPrimaryDark,
                lineHeight = 58.sp
            )
            Text(
                text = "Puntos de Salud",
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = TextSecondaryDark
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = if (isOptimized || score >= 90) "ESTADO ÓPTIMO" else "REQUIERE OPTIMIZACIÓN",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = primaryColor.copy(alpha = pulseAlpha),
                letterSpacing = 1.sp
            )
        }
    }
}
