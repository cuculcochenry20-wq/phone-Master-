package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.EnergySavingsLeaf
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DrainLevel
import com.example.data.model.HibernationAppItem
import com.example.ui.components.PhoneMasterTopBar
import com.example.ui.theme.TecnoCyanGlow
import com.example.ui.theme.TecnoGreenSuccess
import com.example.ui.theme.TecnoNavyCard
import com.example.ui.theme.TecnoNavyCardBorder
import com.example.ui.theme.TecnoNavyDark
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark

@Composable
fun AppHibernationScreen(
    apps: List<HibernationAppItem>,
    isHibernating: Boolean,
    onToggleSelect: (String) -> Unit,
    onSelectAll: (Boolean) -> Unit,
    onHibernateSelected: () -> Unit,
    onHibernateSingle: (String) -> Unit,
    onWakeApp: (String) -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }
    val context = LocalContext.current

    var selectedTab by remember { mutableIntStateOf(0) } // 0: Activas / Consumiendo, 1: Hibernadas (Freezer)

    val activeApps = apps.filter { !it.isHibernated }
    val hibernatedApps = apps.filter { it.isHibernated }

    val displayedApps = if (selectedTab == 0) activeApps else hibernatedApps
    val selectedToHibernate = activeApps.filter { it.isSelected }

    val totalSavedHours = hibernatedApps.sumOf { (it.drainPercentPerHour * 0.4).toDouble() }
    val totalSavedMah = hibernatedApps.sumOf { it.estimatedMahDrain }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(TecnoNavyDark)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            PhoneMasterTopBar(
                title = "Hibernación de Apps",
                subtitle = "Freezer y Ahorro Extremo HiOS",
                showBackButton = true,
                onBackClick = onBack
            )

            // Frosty Hero Status Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(
                        Brush.verticalGradient(
                            listOf(
                                Color(0xFF0F2B48),
                                TecnoNavyCard
                            )
                        )
                    )
                    .border(1.dp, TecnoCyanGlow.copy(alpha = 0.35f), RoundedCornerShape(20.dp))
                    .padding(18.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AcUnit,
                                contentDescription = null,
                                tint = TecnoCyanGlow,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Freezer Activo",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = TecnoCyanGlow,
                                letterSpacing = 1.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(
                            text = if (hibernatedApps.isNotEmpty()) {
                                "+${String.format("%.1f", totalSavedHours)}h de batería ganadas"
                            } else {
                                "${activeApps.size} apps consumiendo energía"
                            },
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold,
                            color = TextPrimaryDark
                        )

                        Text(
                            text = if (hibernatedApps.isNotEmpty()) {
                                "${hibernatedApps.size} apps en suspensión profunda (${totalSavedMah} mAh/h ahorrados)"
                            } else {
                                "Hiberna apps para detener servicios en segundo plano"
                            },
                            fontSize = 11.sp,
                            color = TextSecondaryDark
                        )
                    }

                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(TecnoCyanGlow.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.EnergySavingsLeaf,
                            contentDescription = "Ahorro",
                            tint = TecnoCyanGlow,
                            modifier = Modifier.size(30.dp)
                        )
                    }
                }
            }

            // Tabs: Activas vs Hibernadas
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = TecnoNavyDark,
                contentColor = TecnoCyanGlow,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = TecnoCyanGlow
                    )
                },
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Text(
                            text = "Apps Activas (${activeApps.size})",
                            fontSize = 12.sp,
                            fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Text(
                            text = "Hibernadas (${hibernatedApps.size})",
                            fontSize = 12.sp,
                            fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                )
            }

            // Selection controls if in active tab
            if (selectedTab == 0 && activeApps.isNotEmpty()) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Apps que consumen batería en 2do plano",
                        fontSize = 12.sp,
                        color = TextSecondaryDark
                    )

                    val allSelected = activeApps.all { it.isSelected }
                    TextButton(
                        onClick = { onSelectAll(!allSelected) },
                        modifier = Modifier.testTag("select_all_hibernation_button")
                    ) {
                        Text(
                            text = if (allSelected) "Deseleccionar" else "Seleccionar Todo",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TecnoCyanGlow
                        )
                    }
                }
            }

            // List of Apps
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 6.dp, bottom = 95.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (displayedApps.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 40.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = if (selectedTab == 0) Icons.Default.EnergySavingsLeaf else Icons.Default.AcUnit,
                                    contentDescription = null,
                                    tint = TextSecondaryDark,
                                    modifier = Modifier.size(44.dp)
                                )
                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = if (selectedTab == 0) "¡Excelente! No hay apps con alto consumo activo" else "Aún no tienes apps hibernadas en el Freezer",
                                    fontSize = 13.sp,
                                    color = TextSecondaryDark,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }
                } else {
                    items(displayedApps, key = { it.packageName }) { app ->
                        HibernationAppCard(
                            app = app,
                            onToggleSelect = { onToggleSelect(app.packageName) },
                            onHibernateSingle = { onHibernateSingle(app.packageName) },
                            onWakeApp = { onWakeApp(app.packageName) },
                            onOpenSystemSettings = {
                                try {
                                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                        data = Uri.parse("package:${app.packageName}")
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    context.startActivity(intent)
                                } catch (_: Exception) {}
                            }
                        )
                    }
                }
            }
        }

        // Bottom Action Button for Active Tab
        if (selectedTab == 0 && activeApps.isNotEmpty()) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(TecnoNavyDark)
                    .padding(16.dp)
            ) {
                Button(
                    onClick = onHibernateSelected,
                    enabled = selectedToHibernate.isNotEmpty() && !isHibernating,
                    modifier = Modifier
                        .testTag("hibernate_selected_button")
                        .fillMaxWidth()
                        .height(54.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF00B0FF),
                        disabledContainerColor = TecnoNavyCardBorder
                    )
                ) {
                    if (isHibernating) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(24.dp),
                            strokeWidth = 2.5.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Deteniendo y congelando apps...",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.AcUnit,
                                contentDescription = "Hibernar",
                                tint = Color.White,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (selectedToHibernate.isNotEmpty()) {
                                    "HIBERNAR SELECCIONADAS (${selectedToHibernate.size} APPS)"
                                } else {
                                    "HIBERNAR APLICACIONES"
                                },
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun HibernationAppCard(
    app: HibernationAppItem,
    onToggleSelect: () -> Unit,
    onHibernateSingle: () -> Unit,
    onWakeApp: () -> Unit,
    onOpenSystemSettings: () -> Unit
) {
    val levelColor = Color(app.drainLevel.colorHex)

    Box(
        modifier = Modifier
            .testTag("hibernation_card_${app.packageName}")
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(TecnoNavyCard)
            .border(
                1.dp,
                if (app.isHibernated) TecnoCyanGlow.copy(alpha = 0.3f) else TecnoNavyCardBorder,
                RoundedCornerShape(16.dp)
            )
            .clickable {
                if (!app.isHibernated) onToggleSelect()
            }
            .padding(14.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                if (app.isHibernated) TecnoCyanGlow.copy(alpha = 0.15f)
                                else levelColor.copy(alpha = 0.15f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (app.isHibernated) Icons.Default.AcUnit else Icons.Default.Apps,
                            contentDescription = app.appName,
                            tint = if (app.isHibernated) TecnoCyanGlow else levelColor,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = app.appName,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimaryDark,
                                maxLines = 1
                            )
                            if (app.isHibernated) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(TecnoCyanGlow.copy(alpha = 0.18f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        text = "FREEZER",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = TecnoCyanGlow
                                    )
                                }
                            }
                        }

                        Text(
                            text = if (app.isHibernated) {
                                "En suspensión • Servicios cerrados"
                            } else {
                                "${app.drainLevel.label} • ${String.format("%.1f", app.drainPercentPerHour)}% /h (~${app.estimatedMahDrain} mAh)"
                            },
                            fontSize = 11.sp,
                            color = if (app.isHibernated) TecnoCyanGlow else TextSecondaryDark
                        )
                    }
                }

                if (!app.isHibernated) {
                    Checkbox(
                        checked = app.isSelected,
                        onCheckedChange = { onToggleSelect() },
                        colors = CheckboxDefaults.colors(
                            checkedColor = Color(0xFF00B0FF),
                            checkmarkColor = Color.White,
                            uncheckedColor = TecnoNavyCardBorder
                        ),
                        modifier = Modifier.testTag("checkbox_hibernate_${app.packageName}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons Row: Individual Hibernate / Wake & System Force Stop Shortcut
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // System Settings Shortcut
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clickable { onOpenSystemSettings() }
                        .padding(vertical = 4.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.OpenInNew,
                        contentDescription = "Ajustes del sistema",
                        tint = TextSecondaryDark,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Forzar detención en Android",
                        fontSize = 11.sp,
                        color = TextSecondaryDark,
                        fontWeight = FontWeight.Medium
                    )
                }

                // Quick Action Button
                if (app.isHibernated) {
                    Button(
                        onClick = onWakeApp,
                        modifier = Modifier
                            .testTag("wake_button_${app.packageName}")
                            .height(34.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = TecnoNavyCardBorder)
                    ) {
                        Icon(
                            imageVector = Icons.Default.WbSunny,
                            contentDescription = null,
                            tint = TecnoCyanGlow,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Reactivar",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TecnoCyanGlow
                        )
                    }
                } else {
                    Button(
                        onClick = onHibernateSingle,
                        modifier = Modifier
                            .testTag("hibernate_single_${app.packageName}")
                            .height(34.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0F3255))
                    ) {
                        Icon(
                            imageVector = Icons.Default.PowerSettingsNew,
                            contentDescription = null,
                            tint = Color(0xFF00B0FF),
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Hibernar",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF00B0FF)
                        )
                    }
                }
            }
        }
    }
}
