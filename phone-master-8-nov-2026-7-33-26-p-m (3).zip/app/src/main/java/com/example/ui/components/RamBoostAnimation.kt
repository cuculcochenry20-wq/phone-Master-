package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TecnoBluePrimary
import com.example.ui.theme.TecnoCyanGlow
import com.example.ui.theme.TecnoGreenSuccess
import com.example.ui.theme.TecnoNavyDark
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

private data class SpeedParticle(
    val angleRad: Double,
    val speed: Float,
    val length: Float,
    val strokeWidth: Float,
    val color: Color
)

@Composable
fun RamBoostAnimation(
    freedEstimatedMb: Long,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "boostAnimation")

    // Continuous rotation for speed ring
    val rotationAngle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    // Pulse for rocket flame / energy core
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    // Particle flight phase 0..1
    val particlePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "particles"
    )

    // Simulated progress 0..1
    val progress by infiniteTransition.animateFloat(
        initialValue = 0.15f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "progressBar"
    )

    // Pre-generate random particle directions
    val particles = remember {
        List(24) { index ->
            val angle = (index * (360.0 / 24.0) + Random.nextDouble(-10.0, 10.0)) * Math.PI / 180.0
            SpeedParticle(
                angleRad = angle,
                speed = Random.nextFloat() * 0.7f + 0.3f,
                length = Random.nextFloat() * 40f + 25f,
                strokeWidth = Random.nextFloat() * 2f + 1.5f,
                color = if (index % 3 == 0) TecnoCyanGlow else if (index % 3 == 1) TecnoBluePrimary else Color.White
            )
        }
    }

    val stageText = when {
        progress < 0.35f -> "Escaneando procesos y memoria en 2do plano..."
        progress < 0.70f -> "Deteniendo tareas inactivas y liberando RAM..."
        else -> "Finalizando recolección y compactación de memoria..."
    }

    Box(
        modifier = modifier
            .testTag("ram_boost_animation_overlay")
            .fillMaxSize()
            .background(TecnoNavyDark.copy(alpha = 0.95f)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(28.dp)
        ) {
            // Speed HUD Ring with Rocket & Warp-Speed Particles
            Box(
                modifier = Modifier.size(240.dp),
                contentAlignment = Alignment.Center
            ) {
                // Canvas Warp Particles & Circular Tachometer Rings
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val center = Offset(size.width / 2, size.height / 2)
                    val baseRadius = (size.minDimension / 2) - 30.dp.toPx()

                    // Draw outer spinning neon arc
                    drawArc(
                        brush = Brush.sweepGradient(
                            listOf(TecnoCyanGlow, TecnoBluePrimary, Color.Transparent, TecnoCyanGlow)
                        ),
                        startAngle = rotationAngle,
                        sweepAngle = 260f,
                        useCenter = false,
                        topLeft = Offset(center.x - baseRadius, center.y - baseRadius),
                        size = androidx.compose.ui.geometry.Size(baseRadius * 2, baseRadius * 2),
                        style = Stroke(width = 5.dp.toPx(), cap = StrokeCap.Round)
                    )

                    // Draw reverse inner counter-spinning dashes
                    drawArc(
                        color = TecnoCyanGlow.copy(alpha = 0.4f),
                        startAngle = -rotationAngle * 1.5f,
                        sweepAngle = 140f,
                        useCenter = false,
                        topLeft = Offset(center.x - baseRadius + 14.dp.toPx(), center.y - baseRadius + 14.dp.toPx()),
                        size = androidx.compose.ui.geometry.Size((baseRadius - 14.dp.toPx()) * 2, (baseRadius - 14.dp.toPx()) * 2),
                        style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
                    )

                    // Draw radiating hyper-speed particle lines
                    particles.forEach { p ->
                        val currentDistance = baseRadius * 0.4f + (baseRadius * 0.8f * ((particlePhase * p.speed) % 1f))
                        val startX = (center.x + currentDistance * cos(p.angleRad)).toFloat()
                        val startY = (center.y + currentDistance * sin(p.angleRad)).toFloat()
                        val endX = (center.x + (currentDistance + p.length) * cos(p.angleRad)).toFloat()
                        val endY = (center.y + (currentDistance + p.length) * sin(p.angleRad)).toFloat()

                        drawLine(
                            color = p.color.copy(alpha = (1f - ((particlePhase * p.speed) % 1f)) * 0.9f),
                            start = Offset(startX, startY),
                            end = Offset(endX, endY),
                            strokeWidth = p.strokeWidth,
                            cap = StrokeCap.Round
                        )
                    }

                    // Central glowing aura
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(TecnoCyanGlow.copy(alpha = 0.35f * pulseScale), Color.Transparent)
                        ),
                        radius = baseRadius * 0.55f * pulseScale,
                        center = center
                    )
                }

                // Center Rocket Icon with Pulse
                Box(
                    modifier = Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                listOf(TecnoBluePrimary, TecnoCyanGlow)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.RocketLaunch,
                        contentDescription = "Acelerador de RAM",
                        tint = Color.Black,
                        modifier = Modifier.size(36.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Dynamic Counter
            Text(
                text = "ACELERANDO RAM",
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                color = TecnoCyanGlow,
                letterSpacing = 2.sp
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Liberando aprox. +${(freedEstimatedMb * progress).toLong().coerceAtLeast(180L)} MB",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TecnoGreenSuccess
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = stageText,
                fontSize = 12.sp,
                color = TextSecondaryDark,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(20.dp))

            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth(0.75f)
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = TecnoCyanGlow,
                trackColor = TecnoNavyDark.copy(alpha = 0.6f)
            )
        }
    }
}
