package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import com.example.ui.components.JunkCleanAnimation
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.JunkCategory
import com.example.data.model.formatBytes
import com.example.ui.components.PhoneMasterTopBar
import com.example.ui.theme.TecnoCyanGlow
import com.example.ui.theme.TecnoGreenSuccess
import com.example.ui.theme.TecnoNavyCard
import com.example.ui.theme.TecnoNavyCardBorder
import com.example.ui.theme.TecnoNavyDark
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark

@Composable
fun JunkCleanerScreen(
    categories: List<JunkCategory>,
    isCleaning: Boolean,
    onToggleCategory: (String) -> Unit,
    onSelectAll: (Boolean) -> Unit,
    onClean: () -> Unit,
    onBack: () -> Unit
) {
    BackHandler { onBack() }

    val totalSelectedBytes = categories.filter { it.isSelected }.sumOf { it.sizeBytes }
    val allSelected = categories.isNotEmpty() && categories.all { it.isSelected }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(TecnoNavyDark)
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            PhoneMasterTopBar(
                title = "Limpiador de Basura",
                subtitle = "Optimización de Almacenamiento",
                showBackButton = true,
                onBackClick = onBack
            )

            // Header Banner with Total Junk Found
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(TecnoNavyCard)
                    .border(1.dp, TecnoNavyCardBorder, RoundedCornerShape(20.dp))
                    .padding(20.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(TecnoGreenSuccess.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.CleaningServices,
                            contentDescription = "Limpieza",
                            tint = TecnoGreenSuccess,
                            modifier = Modifier.size(30.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = formatBytes(totalSelectedBytes),
                        fontSize = 34.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = TecnoGreenSuccess
                    )

                    Text(
                        text = if (totalSelectedBytes > 0) "Archivos basura listos para eliminar" else "Almacenamiento completamente limpio",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextSecondaryDark
                    )
                }
            }

            // Select All Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Elementos Detectados (${categories.size})",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimaryDark
                )

                TextButton(
                    onClick = { onSelectAll(!allSelected) },
                    modifier = Modifier.testTag("select_all_junk_button")
                ) {
                    Text(
                        text = if (allSelected) "Deseleccionar Todo" else "Seleccionar Todo",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TecnoCyanGlow
                    )
                }
            }

            // Categories List
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 16.dp),
                contentPadding = PaddingValues(bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(categories, key = { it.id }) { category ->
                    JunkCategoryCard(
                        category = category,
                        onToggle = { onToggleCategory(category.id) }
                    )
                }
            }
        }

        // Bottom Action Button
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .background(TecnoNavyDark)
                .padding(16.dp)
        ) {
            Button(
                onClick = onClean,
                enabled = totalSelectedBytes > 0 && !isCleaning,
                modifier = Modifier
                    .testTag("clean_junk_button")
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = TecnoGreenSuccess,
                    disabledContainerColor = TecnoNavyCardBorder
                )
            ) {
                if (isCleaning) {
                    CircularProgressIndicator(
                        color = Color.Black,
                        modifier = Modifier.size(24.dp),
                        strokeWidth = 2.5.dp
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Limpiando archivos...",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.Black
                    )
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Limpiar",
                            tint = Color.Black,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (totalSelectedBytes > 0) "LIMPIAR BASURA (${formatBytes(totalSelectedBytes)})" else "TODO LIMPIO",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.Black
                        )
                    }
                }
            }
        }

        // High-Tech Compose Progress Animation Overlay
        AnimatedVisibility(
            visible = isCleaning,
            enter = fadeIn(),
            exit = fadeOut()
        ) {
            JunkCleanAnimation(totalBytesToClean = totalSelectedBytes)
        }
    }
}

@Composable
private fun JunkCategoryCard(
    category: JunkCategory,
    onToggle: () -> Unit
) {
    var expanded by remember { mutableStateOf(false) }

    val icon = when (category.iconKey) {
        "cache" -> Icons.Default.Storage
        "residual" -> Icons.Default.Delete
        "apk" -> Icons.Default.Android
        "logs" -> Icons.Default.Description
        else -> Icons.Default.FolderZip
    }

    Box(
        modifier = Modifier
            .testTag("junk_category_${category.id}")
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(TecnoNavyCard)
            .border(1.dp, TecnoNavyCardBorder, RoundedCornerShape(16.dp))
            .clickable { expanded = !expanded }
            .padding(14.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(TecnoCyanGlow.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = icon,
                            contentDescription = category.title,
                            tint = TecnoCyanGlow,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column {
                        Text(
                            text = category.title,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimaryDark
                        )
                        Text(
                            text = category.subtitle,
                            fontSize = 11.sp,
                            color = TextSecondaryDark
                        )
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = category.sizeFormatted,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (category.sizeBytes > 0) TecnoGreenSuccess else TextSecondaryDark
                    )

                    Checkbox(
                        checked = category.isSelected,
                        onCheckedChange = { onToggle() },
                        colors = CheckboxDefaults.colors(
                            checkedColor = TecnoGreenSuccess,
                            checkmarkColor = Color.Black,
                            uncheckedColor = TecnoNavyCardBorder
                        ),
                        modifier = Modifier.testTag("checkbox_${category.id}")
                    )
                }
            }

            AnimatedVisibility(visible = expanded && category.items.isNotEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp, start = 12.dp)
                ) {
                    category.items.forEach { item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "• ${item.name}",
                                fontSize = 11.sp,
                                color = TextSecondaryDark,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                text = item.sizeFormatted,
                                fontSize = 11.sp,
                                color = TecnoCyanGlow,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }
            }
        }
    }
}
