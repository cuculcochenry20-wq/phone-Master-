package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.outlined.BatteryChargingFull
import androidx.compose.material.icons.outlined.Build
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.FullOptimizationOverlay
import com.example.ui.components.OptimizationResultDialog
import com.example.ui.screens.AppHibernationScreen
import com.example.ui.screens.AppManagerScreen
import com.example.ui.screens.AudioEqualizerScreen
import com.example.ui.screens.BatteryLabScreen
import com.example.ui.screens.CpuCoolerScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.JunkCleanerScreen
import com.example.ui.screens.PhoneBoostScreen
import com.example.ui.screens.ToolboxScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.TecnoCyanGlow
import com.example.ui.theme.TecnoNavyCard
import com.example.ui.theme.TecnoNavyCardBorder
import com.example.ui.theme.TecnoNavyDark
import com.example.ui.theme.TextPrimaryDark
import com.example.ui.theme.TextSecondaryDark
import com.example.ui.viewmodel.PhoneMasterViewModel
import com.example.ui.viewmodel.Screen

private data class NavItem(
    val screen: Screen,
    val title: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val testTag: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            val permissionCheck = androidx.core.content.ContextCompat.checkSelfPermission(
                this,
                android.Manifest.permission.POST_NOTIFICATIONS
            )
            if (permissionCheck != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                androidx.core.app.ActivityCompat.requestPermissions(
                    this,
                    arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),
                    101
                )
            }
        }

        setContent {
            MyApplicationTheme {
                val viewModel: PhoneMasterViewModel = viewModel()
                val uiState by viewModel.uiState.collectAsStateWithLifecycle()

                val isMainTab = uiState.currentScreen in listOf(Screen.HOME, Screen.BATTERY_LAB, Screen.TOOLBOX)

                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = TecnoNavyDark,
                    bottomBar = {
                        if (isMainTab) {
                            PhoneMasterBottomBar(
                                currentScreen = uiState.currentScreen,
                                onSelect = { viewModel.navigateTo(it) }
                            )
                        }
                    }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (uiState.currentScreen) {
                            Screen.HOME -> {
                                HomeScreen(
                                    uiState = uiState,
                                    onNavigate = { viewModel.navigateTo(it) },
                                    onOptimizeAll = { viewModel.optimizeEverything100() },
                                    onRefresh = { viewModel.refreshTelemetry() }
                                )
                            }
                            Screen.JUNK_CLEANER -> {
                                JunkCleanerScreen(
                                    categories = uiState.junkCategories,
                                    isCleaning = uiState.isCleaningJunk,
                                    onToggleCategory = { viewModel.toggleJunkCategory(it) },
                                    onSelectAll = { viewModel.selectAllJunk(it) },
                                    onClean = { viewModel.cleanJunk() },
                                    onBack = { viewModel.navigateTo(Screen.HOME) }
                                )
                            }
                            Screen.PHONE_BOOST -> {
                                PhoneBoostScreen(
                                    ramInfo = uiState.ramInfo,
                                    tasks = uiState.runningTasks,
                                    isBoosting = uiState.isBoostingRam,
                                    onToggleTask = { viewModel.toggleTask(it) },
                                    onBoost = { viewModel.boostRam() },
                                    onBack = { viewModel.navigateTo(Screen.HOME) }
                                )
                            }
                            Screen.CPU_COOLER -> {
                                CpuCoolerScreen(
                                    cpuInfo = uiState.cpuInfo,
                                    isCooling = uiState.isCoolingCpu,
                                    onCoolCpu = { viewModel.coolCpu() },
                                    onBack = { viewModel.navigateTo(Screen.HOME) }
                                )
                            }
                            Screen.BATTERY_LAB -> {
                                BatteryLabScreen(
                                    batteryInfo = uiState.batteryInfo,
                                    onSelectMode = { viewModel.setBatteryMode(it) },
                                    onNavigateToHibernation = { viewModel.navigateTo(Screen.APP_HIBERNATION) },
                                    onBack = { viewModel.navigateTo(Screen.HOME) }
                                )
                            }
                            Screen.TOOLBOX -> {
                                ToolboxScreen(
                                    networkInfo = uiState.networkInfo,
                                    isGameMode = uiState.isGameModeEnabled,
                                    onToggleGameMode = { viewModel.toggleGameMode() },
                                    onNavigate = { viewModel.navigateTo(it) },
                                    onBack = { viewModel.navigateTo(Screen.HOME) }
                                )
                            }
                            Screen.APP_MANAGER -> {
                                AppManagerScreen(
                                    apps = uiState.installedApps,
                                    isLoading = uiState.isLoadingApps,
                                    onBack = { viewModel.navigateTo(Screen.TOOLBOX) }
                                )
                            }
                            Screen.APP_HIBERNATION -> {
                                AppHibernationScreen(
                                    apps = uiState.hibernationApps,
                                    isHibernating = uiState.isHibernating,
                                    onToggleSelect = { viewModel.toggleHibernationSelect(it) },
                                    onSelectAll = { viewModel.selectAllHibernation(it) },
                                    onHibernateSelected = { viewModel.hibernateSelectedApps() },
                                    onHibernateSingle = { viewModel.hibernateSingleApp(it) },
                                    onWakeApp = { viewModel.wakeApp(it) },
                                    onBack = { viewModel.navigateTo(Screen.BATTERY_LAB) }
                                )
                            }
                            Screen.EQUALIZER -> {
                                AudioEqualizerScreen(
                                    audioState = uiState.audioState,
                                    factoryPresets = com.example.data.audio.AudioEnhancerManager(this@MainActivity).factoryPresets,
                                    onToggleEnabled = { viewModel.setAudioEqualizerEnabled(it) },
                                    onSelectPreset = { viewModel.selectAudioPreset(it) },
                                    onBandChange = { band, level -> viewModel.setBandLevel(band, level) },
                                    onBassBoostChange = { viewModel.setBassBoost(it) },
                                    onLoudnessChange = { viewModel.setLoudnessGain(it) },
                                    onVirtualizerChange = { viewModel.setVirtualizer(it) },
                                    onSaveCustomPreset = { viewModel.saveCustomPreset(it) },
                                    onDeleteCustomPreset = { viewModel.deleteCustomPreset(it) },
                                    onToggleTestTone = { viewModel.toggleTestAudio() },
                                    onBack = { viewModel.navigateTo(Screen.TOOLBOX) }
                                )
                            }
                        }

                        // Full Screen 100% Boost HUD Overlay
                        AnimatedVisibility(
                            visible = uiState.isOptimizingAll,
                            enter = fadeIn(),
                            exit = fadeOut()
                        ) {
                            FullOptimizationOverlay(
                                progress = uiState.optimizationProgress,
                                statusText = uiState.optimizationStepText
                            )
                        }

                        // Results Dialog
                        if (uiState.showResultDialog && uiState.lastResult != null) {
                            OptimizationResultDialog(
                                result = uiState.lastResult!!,
                                onDismiss = { viewModel.dismissResultDialog() }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PhoneMasterBottomBar(
    currentScreen: Screen,
    onSelect: (Screen) -> Unit
) {
    val items = listOf(
        NavItem(
            screen = Screen.HOME,
            title = "Inicio",
            selectedIcon = Icons.Filled.Home,
            unselectedIcon = Icons.Outlined.Home,
            testTag = "nav_home"
        ),
        NavItem(
            screen = Screen.BATTERY_LAB,
            title = "Batería",
            selectedIcon = Icons.Filled.BatteryChargingFull,
            unselectedIcon = Icons.Outlined.BatteryChargingFull,
            testTag = "nav_battery"
        ),
        NavItem(
            screen = Screen.TOOLBOX,
            title = "Herramientas",
            selectedIcon = Icons.Filled.Build,
            unselectedIcon = Icons.Outlined.Build,
            testTag = "nav_toolbox"
        )
    )

    NavigationBar(
        modifier = Modifier
            .navigationBarsPadding()
            .fillMaxWidth()
            .height(68.dp)
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            .border(
                1.dp,
                TecnoNavyCardBorder,
                RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp)
            ),
        containerColor = TecnoNavyCard,
        tonalElevation = 8.dp
    ) {
        items.forEach { item ->
            val isSelected = currentScreen == item.screen
            NavigationBarItem(
                selected = isSelected,
                onClick = { onSelect(item.screen) },
                icon = {
                    Icon(
                        imageVector = if (isSelected) item.selectedIcon else item.unselectedIcon,
                        contentDescription = item.title,
                        tint = if (isSelected) Color.Black else TextSecondaryDark,
                        modifier = Modifier.size(22.dp)
                    )
                },
                label = {
                    Text(
                        text = item.title,
                        fontSize = 11.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) TecnoCyanGlow else TextSecondaryDark
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = TecnoCyanGlow,
                    selectedIconColor = Color.Black,
                    unselectedIconColor = TextSecondaryDark,
                    selectedTextColor = TecnoCyanGlow,
                    unselectedTextColor = TextSecondaryDark
                ),
                modifier = Modifier.testTag(item.testTag)
            )
        }
    }
}
