package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.repository.SystemOptimizerRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class PhoneMasterTurboService : Service() {

    private val serviceJob = Job()
    private val serviceScope = CoroutineScope(Dispatchers.Default + serviceJob)
    private lateinit var repository: SystemOptimizerRepository

    companion object {
        const val CHANNEL_ID = "phone_master_turbo_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_START_TURBO = "ACTION_START_TURBO"
        const val ACTION_STOP_TURBO = "ACTION_STOP_TURBO"
        const val ACTION_TRIGGER_BOOST = "ACTION_TRIGGER_BOOST"

        private val _isTurboRunning = MutableStateFlow(false)
        val isTurboRunning = _isTurboRunning.asStateFlow()

        fun startTurbo(context: Context) {
            val intent = Intent(context, PhoneMasterTurboService::class.java).apply {
                action = ACTION_START_TURBO
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopTurbo(context: Context) {
            val intent = Intent(context, PhoneMasterTurboService::class.java).apply {
                action = ACTION_STOP_TURBO
            }
            context.startService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        repository = SystemOptimizerRepository(applicationContext)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_TURBO -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
                _isTurboRunning.value = false
                return START_NOT_STICKY
            }
            ACTION_TRIGGER_BOOST -> {
                serviceScope.launch {
                    val tasks = repository.getRunningTasks()
                    repository.boostPhone(tasks)
                    updateNotification("¡RAM optimizada en segundo plano!")
                }
            }
            else -> {
                _isTurboRunning.value = true
                startForeground(NOTIFICATION_ID, buildNotification("CPU/GPU al 100% de potencia • Protección de RAM activa"))
                startContinuousOptimizationLoop()
            }
        }

        // START_STICKY ensures service automatically restarts if system kills it or user closes recent apps
        return START_STICKY
    }

    private fun startContinuousOptimizationLoop() {
        serviceScope.launch {
            while (isActive) {
                delay(30_000) // Periodic 30s background stabilizer
                try {
                    val ram = repository.getRamInfo()
                    if (ram.usedPercent > 75) {
                        val tasks = repository.getRunningTasks()
                        repository.boostPhone(tasks)
                        updateNotification("RAM estabilizada automáticamente (${ram.usedPercent}% en uso)")
                    }
                } catch (_: Exception) { }
            }
        }
    }

    private fun buildNotification(statusText: String): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingLaunch = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, PhoneMasterTurboService::class.java).apply {
            action = ACTION_STOP_TURBO
        }
        val pendingStop = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val boostIntent = Intent(this, PhoneMasterTurboService::class.java).apply {
            action = ACTION_TRIGGER_BOOST
        }
        val pendingBoost = PendingIntent.getService(
            this,
            2,
            boostIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("⚡ Phone Master: Modo Turbo 100% Activo")
            .setContentText(statusText)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingLaunch)
            .addAction(android.R.drawable.ic_menu_rotate, "Acelerar", pendingBoost)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Detener Turbo", pendingStop)
            .build()
    }

    private fun updateNotification(text: String) {
        val notificationManager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(NOTIFICATION_ID, buildNotification(text))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Modo Turbo y Rendimiento Phone Master",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Mantiene el rendimiento continuo del teléfono activo en primer y segundo plano"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceJob.cancel()
        _isTurboRunning.value = false
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
