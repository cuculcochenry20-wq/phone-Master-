package com.example.data.model

enum class BatteryMode(val label: String, val extraHours: Float, val description: String, val isTurbo: Boolean = false) {
    TURBO("Modo Turbo Rendimiento 100%", -1.5f, "Máxima potencia CPU/GPU y prioridad de memoria para juegos y apps exigentes", true),
    NORMAL("Modo Equilibrado", 0.0f, "Rendimiento óptimo para todas las funciones", false),
    SMART_SAVER("Ahorro Inteligente", 3.5f, "Limita apps en segundo plano y sincronización", false),
    ULTRA_SAVER("Ultra Ahorro", 14.0f, "Solo llamadas, SMS y funciones esenciales", false),
    SLEEP("Modo Nocturno", 6.0f, "Ahorro programado durante la noche", false)
}

data class RamInfo(
    val totalBytes: Long = 0L,
    val availableBytes: Long = 0L,
    val usedBytes: Long = 0L,
    val usedPercent: Int = 0,
    val thresholdBytes: Long = 0L,
    val isLowMemory: Boolean = false
) {
    val totalGbFormatted: String get() = String.format("%.1f GB", totalBytes / (1024.0 * 1024 * 1024))
    val usedGbFormatted: String get() = String.format("%.1f GB", usedBytes / (1024.0 * 1024 * 1024))
    val availableGbFormatted: String get() = String.format("%.1f GB", availableBytes / (1024.0 * 1024 * 1024))
}

data class StorageInfo(
    val totalBytes: Long = 0L,
    val availableBytes: Long = 0L,
    val usedBytes: Long = 0L,
    val usedPercent: Int = 0
) {
    val totalGbFormatted: String get() = String.format("%.1f GB", totalBytes / (1024.0 * 1024 * 1024))
    val usedGbFormatted: String get() = String.format("%.1f GB", usedBytes / (1024.0 * 1024 * 1024))
    val availableGbFormatted: String get() = String.format("%.1f GB", availableBytes / (1024.0 * 1024 * 1024))
}

data class CpuThermalInfo(
    val temperatureCelsius: Float = 33.5f,
    val statusText: String = "Normal",
    val isOverheated: Boolean = false,
    val cpuUsagePercent: Int = 42,
    val gpuStatusText: String = "Óptimo",
    val hotAppsCount: Int = 3
)

data class BatteryInfo(
    val levelPercent: Int = 78,
    val isCharging: Boolean = false,
    val chargeSource: String = "Batería",
    val health: String = "Buena",
    val voltageMv: Int = 4050,
    val temperatureCelsius: Float = 32.0f,
    val estimatedRemainingHours: Float = 16.5f,
    val activeMode: BatteryMode = BatteryMode.NORMAL
)

data class JunkFileItem(
    val id: String,
    val name: String,
    val path: String,
    val sizeBytes: Long,
    val isSelected: Boolean = true
) {
    val sizeFormatted: String get() = formatBytes(sizeBytes)
}

data class JunkCategory(
    val id: String,
    val title: String,
    val subtitle: String,
    val iconKey: String,
    val sizeBytes: Long,
    val isSelected: Boolean = true,
    val items: List<JunkFileItem> = emptyList()
) {
    val sizeFormatted: String get() = formatBytes(sizeBytes)
}

data class RunningAppTask(
    val packageName: String,
    val appName: String,
    val ramUsageMb: Long,
    val isSelected: Boolean = true,
    val isSystemApp: Boolean = false
)

data class InstalledAppItem(
    val packageName: String,
    val appName: String,
    val versionName: String,
    val sizeBytes: Long,
    val isSystemApp: Boolean,
    val installDate: Long
) {
    val sizeFormatted: String get() = formatBytes(sizeBytes)
}

enum class DrainLevel(val label: String, val colorHex: Long) {
    HIGH("Alto Consumo", 0xFFFF5252),
    MODERATE("Consumo Medio", 0xFFFFAB00),
    LOW("Consumo Bajo", 0xFF00E676)
}

data class HibernationAppItem(
    val packageName: String,
    val appName: String,
    val drainPercentPerHour: Float,
    val estimatedMahDrain: Int,
    val isHibernated: Boolean = false,
    val isSelected: Boolean = true,
    val drainLevel: DrainLevel = DrainLevel.HIGH,
    val backgroundServicesCount: Int = 2
)

data class OptimizationResult(
    val ramFreedMb: Long,
    val junkFreedMb: Long,
    val coolingDegrees: Float,
    val batteryExtraHours: Float,
    val previousScore: Int,
    val newScore: Int = 100
)

fun formatBytes(bytes: Long): String {
    if (bytes <= 0) return "0 MB"
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    val gb = mb / 1024.0
    return when {
        gb >= 1.0 -> String.format("%.2f GB", gb)
        mb >= 1.0 -> String.format("%.1f MB", mb)
        else -> String.format("%.0f KB", kb)
    }
}
