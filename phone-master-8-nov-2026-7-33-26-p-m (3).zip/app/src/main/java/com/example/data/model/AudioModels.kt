package com.example.data.model

data class EqualizerBand(
    val index: Int,
    val centerFreqHz: Int,
    val minLevelMdB: Int = -1500,
    val maxLevelMdB: Int = 1500,
    val currentLevelMdB: Int = 0
) {
    val freqFormatted: String
        get() = if (centerFreqHz >= 1000) "${centerFreqHz / 1000} kHz" else "$centerFreqHz Hz"

    val levelFormatted: String
        get() = "${if (currentLevelMdB > 0) "+" else ""}${currentLevelMdB / 100} dB"
}

data class EqualizerPreset(
    val id: String,
    val name: String,
    val bandLevels: List<Int>, // in millibels (-1500..+1500)
    val bassBoost: Int = 0,    // 0..1000
    val loudnessGain: Int = 0, // 0..1200 mB
    val isCustom: Boolean = false
)

data class AudioEnhancerState(
    val isEnabled: Boolean = true,
    val currentPresetId: String = "preset_bass_boost",
    val bands: List<EqualizerBand> = emptyList(),
    val bassBoostStrength: Int = 750,   // 0..1000
    val loudnessGainMdB: Int = 600,     // 0..1200 mB
    val virtualizerStrength: Int = 400, // 0..1000
    val customPresets: List<EqualizerPreset> = emptyList(),
    val isTestingTone: Boolean = false
)
