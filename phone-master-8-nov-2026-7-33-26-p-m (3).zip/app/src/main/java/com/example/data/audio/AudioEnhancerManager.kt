package com.example.data.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import android.os.Build
import com.example.data.model.AudioEnhancerState
import com.example.data.model.EqualizerBand
import com.example.data.model.EqualizerPreset
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.sin

class AudioEnhancerManager(private val context: Context) {

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var loudnessEnhancer: LoudnessEnhancer? = null
    private var virtualizer: Virtualizer? = null
    private var testAudioTrack: AudioTrack? = null

    val factoryPresets: List<EqualizerPreset> = listOf(
        EqualizerPreset(
            id = "preset_bass_boost",
            name = "Bajos Fuertes + Volumen Alto",
            bandLevels = listOf(1000, 600, 100, 400, 700),
            bassBoost = 850,
            loudnessGain = 800
        ),
        EqualizerPreset(
            id = "preset_rock",
            name = "Rock Dinámico",
            bandLevels = listOf(500, 300, -100, 400, 600),
            bassBoost = 500,
            loudnessGain = 400
        ),
        EqualizerPreset(
            id = "preset_pop",
            name = "Pop Cristalino",
            bandLevels = listOf(200, 400, 200, 300, 400),
            bassBoost = 400,
            loudnessGain = 300
        ),
        EqualizerPreset(
            id = "preset_vocal",
            name = "Voz y Claridad",
            bandLevels = listOf(-200, 100, 600, 500, 200),
            bassBoost = 150,
            loudnessGain = 400
        ),
        EqualizerPreset(
            id = "preset_club",
            name = "Club / Electrónica",
            bandLevels = listOf(800, 500, -200, 500, 800),
            bassBoost = 900,
            loudnessGain = 600
        ),
        EqualizerPreset(
            id = "preset_flat",
            name = "Plano / Por Defecto",
            bandLevels = listOf(0, 0, 0, 0, 0),
            bassBoost = 0,
            loudnessGain = 0
        )
    )

    fun initializeAudioFx(): AudioEnhancerState {
        val defaultFrequencies = listOf(60, 230, 910, 3600, 14000)
        val bands = mutableListOf<EqualizerBand>()

        try {
            // Audio Session 0 targets the global audio mix output
            equalizer = Equalizer(1000, 0).apply { enabled = true }
            bassBoost = BassBoost(1000, 0).apply { enabled = true }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                loudnessEnhancer = LoudnessEnhancer(0).apply { enabled = true }
            }
            virtualizer = Virtualizer(1000, 0).apply { enabled = true }

            val numBands = equalizer?.numberOfBands?.toInt() ?: 5
            val minLevel = equalizer?.bandLevelRange?.get(0)?.toInt() ?: -1500
            val maxLevel = equalizer?.bandLevelRange?.get(1)?.toInt() ?: 1500

            for (i in 0 until numBands) {
                val centerFreq = (equalizer?.getCenterFreq(i.toShort()) ?: (defaultFrequencies.getOrNull(i) ?: 1000) * 1000) / 1000
                bands.add(
                    EqualizerBand(
                        index = i,
                        centerFreqHz = centerFreq,
                        minLevelMdB = minLevel,
                        maxLevelMdB = maxLevel,
                        currentLevelMdB = factoryPresets[0].bandLevels.getOrElse(i) { 0 }
                    )
                )
            }
        } catch (_: Exception) {
            // Safe fallback with standard 5-band configuration
            for (i in defaultFrequencies.indices) {
                bands.add(
                    EqualizerBand(
                        index = i,
                        centerFreqHz = defaultFrequencies[i],
                        minLevelMdB = -1500,
                        maxLevelMdB = 1500,
                        currentLevelMdB = factoryPresets[0].bandLevels.getOrElse(i) { 0 }
                    )
                )
            }
        }

        applyPreset(factoryPresets[0])

        return AudioEnhancerState(
            isEnabled = true,
            currentPresetId = factoryPresets[0].id,
            bands = bands,
            bassBoostStrength = factoryPresets[0].bassBoost,
            loudnessGainMdB = factoryPresets[0].loudnessGain,
            virtualizerStrength = 400,
            customPresets = emptyList()
        )
    }

    fun applyPreset(preset: EqualizerPreset) {
        try {
            equalizer?.let { eq ->
                for (i in preset.bandLevels.indices) {
                    if (i < eq.numberOfBands) {
                        eq.setBandLevel(i.toShort(), preset.bandLevels[i].toShort())
                    }
                }
            }
            applyBassBoost(preset.bassBoost)
            applyLoudnessGain(preset.loudnessGain)
        } catch (_: Exception) { }
    }

    fun setBandLevel(bandIndex: Int, levelMdB: Int) {
        try {
            equalizer?.setBandLevel(bandIndex.toShort(), levelMdB.toShort())
        } catch (_: Exception) { }
    }

    fun applyBassBoost(strength: Int) {
        try {
            bassBoost?.let { bb ->
                if (bb.strengthSupported) {
                    bb.setStrength(strength.coerceIn(0, 1000).toShort())
                }
            }
        } catch (_: Exception) { }
    }

    fun applyLoudnessGain(gainMdB: Int) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                loudnessEnhancer?.setTargetGain(gainMdB.coerceIn(0, 1200))
            }
        } catch (_: Exception) { }
    }

    fun applyVirtualizer(strength: Int) {
        try {
            virtualizer?.let { v ->
                if (v.strengthSupported) {
                    v.setStrength(strength.coerceIn(0, 1000).toShort())
                }
            }
        } catch (_: Exception) { }
    }

    fun setEnabled(enabled: Boolean) {
        try {
            equalizer?.enabled = enabled
            bassBoost?.enabled = enabled
            loudnessEnhancer?.enabled = enabled
            virtualizer?.enabled = enabled
        } catch (_: Exception) { }
    }

    /**
     * Play a synthesized test sound combining bass frequencies and harmonics
     * to demonstrate the active equalizer and bass enhancement
     */
    suspend fun playTestAudio(): Unit = withContext(Dispatchers.IO) {
        stopTestAudio()
        try {
            val sampleRate = 44100
            val durationSeconds = 3.0
            val numSamples = (durationSeconds * sampleRate).toInt()
            val buffer = ShortArray(numSamples)

            // Synthesize rich chord with low bass (70 Hz), mid (280 Hz) and high (1200 Hz)
            for (i in 0 until numSamples) {
                val t = i.toDouble() / sampleRate
                val bassWave = sin(2 * Math.PI * 70.0 * t) * 0.55
                val midWave = sin(2 * Math.PI * 280.0 * t) * 0.30
                val highWave = sin(2 * Math.PI * 1200.0 * t) * 0.15
                val envelope = when {
                    t < 0.2 -> (t / 0.2)
                    t > 2.6 -> ((3.0 - t) / 0.4)
                    else -> 1.0
                }
                val sample = ((bassWave + midWave + highWave) * envelope * Short.MAX_VALUE).toInt()
                buffer[i] = sample.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            }

            testAudioTrack = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setBufferSizeInBytes(buffer.size * 2)
                .setTransferMode(AudioTrack.MODE_STATIC)
                .build()

            testAudioTrack?.write(buffer, 0, buffer.size)
            testAudioTrack?.play()
        } catch (_: Exception) { }
    }

    fun stopTestAudio() {
        try {
            testAudioTrack?.stop()
            testAudioTrack?.release()
            testAudioTrack = null
        } catch (_: Exception) { }
    }

    fun release() {
        stopTestAudio()
        try {
            equalizer?.release()
            bassBoost?.release()
            loudnessEnhancer?.release()
            virtualizer?.release()
        } catch (_: Exception) { }
    }
}
